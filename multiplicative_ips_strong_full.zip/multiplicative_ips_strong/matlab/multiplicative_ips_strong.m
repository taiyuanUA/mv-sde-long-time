function output = multiplicative_ips_strong(action, outdir, repeats)
%MULTIPLICATIVE_IPS_STRONG Same-N IPS strong errors for multiplicative noise.
%
% Model (each coordinate):
% dX_i = [-2 X_i - 14 X_i.^3 + 0.5 mean_j(X_j)] dt
%        + sqrt(1+X_i.^2) dW_i.
%
% Main experiment: T=100, N=64, R=16 independent COMPLETE systems;
% d=[2 3 4 5 8], h=2.^(-(11:16)), href=2^-17, alpha=1/8.
% The reference is an Ito--Taylor expansion, NOT an exact solution.
% Full particle interaction is retained in ALL numerical/reference systems.
%
% Usage after adding this folder to the MATLAB path:
%   multiplicative_ips_strong('plot');
%   multiplicative_ips_strong('test');
%   multiplicative_ips_strong('simulate','my_results',16);
%   multiplicative_ips_strong('analyze','my_results');
%   multiplicative_ips_strong('audit','my_audit',2);
%
% No Python, MEX, statistics, or parallel toolbox is required by this file.
% Rerunning the simulation is expensive: it advances every path from 0 to 100.
% MATLAB and the archived C++ run use different random-number generators.

if nargin<1 || isempty(action), action='plot'; end
root=fileparts(fileparts(mfilename('fullpath')));
if nargin<2 || isempty(outdir)
    if strcmpi(action,'audit'), outdir=fullfile(root,'audit');
    else, outdir=fullfile(root,'data'); end
end
C=configuration();
if nargin>=3 && ~isempty(repeats)
    validateattributes(repeats,{'numeric'},{'scalar','integer','positive'});
    C.R=repeats;
elseif strcmpi(action,'audit')
    C.R=2;
end
switch lower(action)
    case 'simulate'
        if ~exist(outdir,'dir'), mkdir(outdir); end
        save(fullfile(outdir,'configuration.mat'),'C');
        fid=fopen(fullfile(outdir,'raw_observations.csv'),'w');
        if fid<0, error('Cannot open output file.'); end
        closer=onCleanup(@()fclose(fid));
        fprintf(fid,'system,t,method,d,h,mse\n');
        rawDiag=zeros(C.R,4); allProjection=[];
        for r=1:C.R
            rng(mod(C.seed+1000003*(r-1),2^32),'twister');
            [obs,diagnostics,projection]=one_system(C);
            rawDiag(r,:)=[r-1,diagnostics.maxres,diagnostics.maxit,diagnostics.refmax];
            for it=1:numel(C.times)
                for method=1:2
                    for di=1:numel(C.dims)
                        for l=1:numel(C.h)
                            fprintf(fid,'%d,%.17g,%s,%d,%.17g,%.17g\n', ...
                                r-1,C.times(it),C.methods{method},C.dims(di),C.h(l),obs(it,method,di,l));
                        end
                    end
                end
            end
            allProjection=[allProjection;repmat(r-1,size(projection,1),1),projection]; %#ok<AGROW>
            save(fullfile(outdir,sprintf('system_%03d.mat',r)),'obs','diagnostics','projection','C');
            fprintf('Completed independent IPS %d/%d.\n',r,C.R);
        end
        clear closer;
        writetable(array2table(rawDiag,'VariableNames', ...
            {'system','max_normalized_residual','max_Newton_updates','reference_max_abs_coordinate'}), ...
            fullfile(outdir,'solver_diagnostics.csv'));
        writetable(array2table(allProjection,'VariableNames', ...
            {'system','d','h','hits','late_hits','updates','late_updates','max_preprojection_norm'}), ...
            fullfile(outdir,'raw_projection.csv'));
        output=analyze_data(outdir,C);
        plot_data(outdir,fullfile(outdir,'figures'));
    case 'analyze'
        output=analyze_data(outdir,C);
    case 'plot'
        if ~exist(fullfile(outdir,'summary.csv'),'file'), analyze_data(outdir,C); end
        plot_data(outdir,fullfile(fileparts(outdir),'figures'));
        output=[];
    case 'audit'
        if ~exist(outdir,'dir'), mkdir(outdir); end
        output=run_audit(C,outdir);
    case 'test'
        output=test_algorithms();
    case 'configuration'
        output=C; disp(C);
    otherwise
        error('Action must be simulate, analyze, plot, audit, test, or configuration.');
end
end

function C=configuration()
C.T=100; C.N=64; C.R=16; C.dims=[2 3 4 5 8]; C.dmax=8;
C.h=2.^(-(11:16)); C.href=2^-17; C.alpha=1/8;
C.times=0:100; C.seed=202609302713; C.auditSeed=202609303719;
C.methods={'SSBE','PM'}; C.boot=5000;
C.ratios=round(C.h/C.href); C.saveStride=round(1/C.href);
assert(all(abs(C.ratios*C.href-C.h)<1e-15));
assert(C.alpha*2<1/3);
end

function [obs,D,P]=one_system(C)
N=C.N; nl=numel(C.h); nd=numel(C.dims);
X=randn(N,C.dmax); X0=X;
YS=cell(1,nl); YP=cell(nd,nl); accum=cell(1,nl);
hits=zeros(nd,nl); latehits=hits; maxNorm=hits;
for l=1:nl
    YS{l}=X0; accum{l}=zeros(N,C.dmax);
    for di=1:nd
        % Separate PM state in each dimension; no prefix projection shortcut.
        YP{di,l}=X0(:,1:C.dims(di));
    end
end
D=struct('maxres',0,'maxit',0,'refmax',0);
obs=zeros(numel(C.times),2,nd,nl); idx=1;
for n=1:round(C.T/C.href)
    dW=sqrt(C.href)*randn(N,C.dmax);
    J=0.5*C.href*dW+sqrt(C.href^3/12)*randn(N,C.dmax);
    X=reference_step(X,dW,J,C.href);
    D.refmax=max(D.refmax,max(abs(X(:))));
    for l=1:nl
        accum{l}=accum{l}+dW;
        if mod(n,C.ratios(l))==0
            [Z,it,res]=implicit_stage(YS{l},C.h(l));
            YS{l}=Z+sqrt(1+Z.^2).*accum{l};
            if any(~isfinite(YS{l}(:))), error('Nonfinite SSBE path.'); end
            D.maxit=max(D.maxit,it); D.maxres=max(D.maxres,res);
            for di=1:nd
                d=C.dims(di);
                [YP{di,l},hit,mx]=pm_step(YP{di,l},accum{l}(:,1:d),C.h(l),C.alpha);
                hits(di,l)=hits(di,l)+hit;
                if n*C.href>=80, latehits(di,l)=latehits(di,l)+hit; end
                maxNorm(di,l)=max(maxNorm(di,l),mx);
            end
            accum{l}(:)=0;
        end
    end
    if mod(n,C.saveStride)==0
        idx=idx+1;
        for di=1:nd
            d=C.dims(di);
            for l=1:nl
                obs(idx,1,di,l)=mean(sum((YS{l}(:,1:d)-X(:,1:d)).^2,2));
                obs(idx,2,di,l)=mean(sum((YP{di,l}-X(:,1:d)).^2,2));
            end
        end
    end
end
P=zeros(nd*nl,7); k=0;
for di=1:nd
    for l=1:nl
        k=k+1;updates=round(C.T/C.h(l))*N;
        lateUpdates=(round((C.T-80)/C.h(l))+1)*N;
        P(k,:)=[C.dims(di),C.h(l),hits(di,l),latehits(di,l),updates,lateUpdates,maxNorm(di,l)];
    end
end
end

function [Z,it,res]=implicit_stage(Y,h)
% Coupled implicit system, including its new-time empirical mean.
a=1+2*h; b=14*h; c=0.5*h; Z=Y;
scale=1+max(abs(Y),[],1);
for it=0:15
    F=(a+b*Z.^2).*Z-c*mean(Z,1)-Y;
    res=max(max(abs(F),[],1)./scale);
    if ~isfinite(res), error('Nonfinite Newton residual.'); end
    if res<=1e-12, return; end
    invD=1./(a+3*b*Z.^2); G=invD.*F;
    denominator=1-c*mean(invD,1);
    if any(denominator<=0), error('Nonpositive Newton denominator.'); end
    shift=c*mean(G,1)./denominator;
    Z=Z-G-invD.*shift;
end
error('SSBE stage failed to reach tolerance.');
end

function [Ynew,hits,maxnorm]=pm_step(Y,dW,h,alpha)
norms=sqrt(sum(Y.^2,2)); maxnorm=max(norms);
factor=min(1,h^(-alpha)./max(norms,realmin));
hits=sum(factor<1); Z=Y.*factor;
B=-2*Z-14*Z.^3+0.5*mean(Z,1);
Ynew=Z+h*B+sqrt(1+Z.^2).*dW+0.5*Z.*(dW.^2-h);
if any(~isfinite(Ynew(:))), error('Nonfinite PM path.'); end
end

function Xnew=reference_step(X,dW,J,h)
% Numerical Ito--Taylor reference; all operations use OLD states.
B=-2*X-14*X.^3+0.5*mean(X,1);
g=sqrt(1+X.^2); bp=-2-42*X.^2;
L0B=bp.*B+0.5*mean(B,1)-42*X.*(1+X.^2);
L0g=(X.*B+0.5)./g;
Xnew=X+h*B+g.*dW+0.5*X.*(dW.^2-h) ...
    +0.5*h^2*L0B+bp.*g.*J+0.5*mean(g.*J,1) ...
    +L0g.*(h*dW-J)+(g/6).*(dW.^3-3*h*dW);
if any(~isfinite(Xnew(:))) || max(abs(Xnew(:)))>1e6
    error('Unstable reference; no path reset, clipping, or rejection is performed.');
end
end

function result=analyze_data(outdir,C)
S=readtable(fullfile(outdir,'raw_observations.csv'));
systems=unique(S.system); R=numel(systems); dims=unique(S.d)'; H=sort(unique(S.h));
methods={'SSBE','PM'}; rows={}; rateRows={}; timeRows={};
rng(314159,'twister'); bootWeights=zeros(C.boot,R);
for b=1:C.boot
    ix=randi(R,[R,1]); bootWeights(b,:)=accumarray(ix,1,[R,1])'/R;
end
for m=1:2
 for di=1:numel(dims)
    d=dims(di); K=numel(H); A=zeros(R,K); W=A;
    for l=1:K
        idx=strcmp(string(S.method),methods{m}) & S.d==d & S.h==H(l);
        Z=S(idx,:);
        for r=1:R
            zr=Z(Z.system==systems(r),:);
            A(r,l)=zr.mse(zr.t==C.T);
            W(r,l)=mean(zr.mse(zr.t>=80 & zr.t<=100));
        end
        time=unique(Z.t);
        for it=1:numel(time)
            x=Z.mse(Z.t==time(it));
            timeRows(end+1,:)={methods{m},d,H(l),time(it),sqrt(mean(x))}; %#ok<AGROW>
        end
        avg=mean(A(:,l)); se=std(A(:,l),0)/sqrt(R);
        rows(end+1,:)={methods{m},d,H(l),avg,sqrt(avg),sqrt(mean(W(:,l))), ...
            sqrt(max(0,avg-1.96*se)),sqrt(avg+1.96*se)}; %#ok<AGROW>
    end
    x=log(H(:)); xc=x-mean(x);
    terminal=0.5*log(mean(A,1)); late=0.5*log(mean(W,1));
    p=polyfit(x,terminal(:),1); pl=polyfit(x,late(:),1);
    betas=(0.5*log(bootWeights*A))*xc/sum(xc.^2);
    bs=sort(betas); lo=bs(max(1,ceil(.025*C.boot))); hi=bs(min(C.boot,ceil(.975*C.boot)));
    adjacent=diff(terminal(:))./diff(x);
    rateRows(end+1,:)={methods{m},d,p(1),lo,hi,pl(1),adjacent(1)}; %#ok<AGROW>
 end
end
U=cell2table(rows,'VariableNames',{'method','d','h','mse','rms','late_rms','ci_low','ci_high'});
Q=cell2table(rateRows,'VariableNames',{'method','d','slope','ci_low','ci_high','late_slope','finest_adjacent_order'});
V=cell2table(timeRows,'VariableNames',{'method','d','h','t','rms'});
writetable(U,fullfile(outdir,'summary.csv'));writetable(Q,fullfile(outdir,'rates.csv'));writetable(V,fullfile(outdir,'time_summary.csv'));
P=readtable(fullfile(outdir,'raw_projection.csv')); pp={};
for d=dims
 for h=H'
    z=P(P.d==d & P.h==h,:);
    pp(end+1,:)={d,h,sum(z.hits),sum(z.updates),100*sum(z.hits)/sum(z.updates), ...
        sum(z.late_hits),sum(z.late_updates),100*sum(z.late_hits)/sum(z.late_updates),max(z.max_preprojection_norm)}; %#ok<AGROW>
 end
end
writetable(cell2table(pp,'VariableNames',{'d','h','hits','updates','hit_percent','late_hits', ...
    'late_updates','late_hit_percent','max_preprojection_norm'}),fullfile(outdir,'projection_summary.csv'));
disp(Q);result=Q;
end

function plot_data(outdir,figdir)
if ~exist(figdir,'dir'), mkdir(figdir); end
S=readtable(fullfile(outdir,'summary.csv')); dims=[2 3 4 5 8];
colors=[.55 .33 .29;.86 .43 .74;.43 .43 .43;.60 .60 0;.05 .45 .75];
markers={'d','s','o','v','x'};methods={'SSBE','PM'};orders=[.5 1];
for m=1:2
    A=S(strcmp(string(S.method),methods{m}),:);H=sort(unique(A.h));
    fig=figure('Color','w','Position',[80 80 1000 700]);ax=axes('Parent',fig,'Position',[.14 .14 .83 .76]);
    hold(ax,'on');box(ax,'on');
    set(ax,'XScale','log','YScale','log','FontSize',13,'LineWidth',1,'TickDir','in','XMinorTick','on','YMinorTick','on');
    grid(ax,'off');hd=logspace(log10(min(H)),log10(max(H)),240);
    coef=1.4*max(A.rms./A.h.^orders(m));
    hh=gobjects(6,1);labels=cell(6,1);
    hh(1)=plot(ax,hd,coef*hd.^orders(m),'--','Color',[0 .60 .15],'LineWidth',1.8);
    labels{1}=sprintf('Reference slope %g',orders(m));
    for q=1:5
        B=sortrows(A(A.d==dims(q),:),'h');p=polyfit(log(B.h),log(B.rms),1);
        plot(ax,hd,exp(polyval(p,log(hd))),'-','Color',colors(q,:),'LineWidth',1.4,'HandleVisibility','off');
        face=colors(q,:);if strcmp(markers{q},'x'),face='none';end
        plot(ax,B.h,B.rms,'LineStyle','none','Marker',markers{q},'Color',colors(q,:),'MarkerFaceColor',face,'MarkerSize',7,'LineWidth',1.2,'HandleVisibility','off');
        hh(q+1)=plot(ax,NaN,NaN,'-','Marker',markers{q},'Color',colors(q,:),'MarkerFaceColor',face,'MarkerSize',7,'LineWidth',1.4);
        labels{q+1}=sprintf('d=%d, slope=%.3f',dims(q),p(1));
    end
    xlabel(ax,'Step size $h$','Interpreter','latex','FontSize',16);
    ylabel(ax,'$\widehat e_{h,d}(T)$','Interpreter','latex','FontSize',18);
    title(ax,['The Strong Convergence Rate of ' methods{m}],'Interpreter','none','FontSize',18,'FontWeight','normal');
    legend(ax,hh,labels,'Location','northwest','Interpreter','none','FontSize',11,'Box','on');
    xlim(ax,[min(H)/1.3,max(H)*1.2]);
    set(fig,'PaperUnits','inches','PaperPosition',[0 0 10 7],'PaperSize',[10 7]);
    base=fullfile(figdir,['multiplicative_' methods{m} '_strong']);
    print(fig,[base '.png'],'-dpng','-r300');print(fig,[base '.pdf'],'-dpdf','-painters');savefig(fig,[base '.fig']);
end
end

function result=run_audit(C,outdir)
N=C.N; K=numel(C.h); nd=numel(C.dims);dt=C.href;dd=dt/2;
fid=fopen(fullfile(outdir,'raw_audit.csv'),'w');if fid<0,error('Cannot open audit output.');end
closer=onCleanup(@()fclose(fid));
fprintf(fid,'system,t,method,d,h,mse_coarse_reference,mse_fine_reference,reference_mse\n');
for r=1:C.R
    rng(mod(C.auditSeed+1000003*(r-1),2^32),'twister');fine=randn(N,C.dmax);coarse=fine;
    YS=cell(1,K);YP=cell(nd,K);accum=cell(1,K);
    for l=1:K
        YS{l}=fine;accum{l}=zeros(N,C.dmax);
        for di=1:nd,YP{di,l}=fine(:,1:C.dims(di));end
    end
    for n=1:round(C.T/dt)
        w1=sqrt(dd)*randn(N,C.dmax);j1=.5*dd*w1+sqrt(dd^3/12)*randn(N,C.dmax);
        w2=sqrt(dd)*randn(N,C.dmax);j2=.5*dd*w2+sqrt(dd^3/12)*randn(N,C.dmax);
        w=w1+w2; J=j1+dd*w1+j2;
        fine=reference_step(fine,w1,j1,dd);fine=reference_step(fine,w2,j2,dd);
        coarse=reference_step(coarse,w,J,dt);
        for l=1:K
            accum{l}=accum{l}+w;
            if mod(n,C.ratios(l))==0
                z=implicit_stage(YS{l},C.h(l));YS{l}=z+sqrt(1+z.^2).*accum{l};
                for di=1:nd
                    d=C.dims(di);YP{di,l}=pm_step(YP{di,l},accum{l}(:,1:d),C.h(l),C.alpha);
                end
                accum{l}(:)=0;
            end
        end
        if mod(n,C.saveStride)==0 && n*dt>=80
            for m=1:2
                for di=1:nd
                    d=C.dims(di);
                    for l=1:K
                        if m==1,y=YS{l}(:,1:d);else,y=YP{di,l};end
                        e1=mean(sum((y-coarse(:,1:d)).^2,2));e2=mean(sum((y-fine(:,1:d)).^2,2));
                        er=mean(sum((coarse(:,1:d)-fine(:,1:d)).^2,2));
                        fprintf(fid,'%d,%.17g,%s,%d,%.17g,%.17g,%.17g,%.17g\n',r-1,n*dt,C.methods{m},d,C.h(l),e1,e2,er);
                    end
                end
            end
        end
    end
    fprintf('Completed reference audit %d/%d.\n',r,C.R);
end
clear closer;
A=readtable(fullfile(outdir,'raw_audit.csv'));rows={};
for m=1:2
 for d=C.dims
  for h=C.h
   for win=1:2
    idx=strcmp(string(A.method),C.methods{m}) & A.d==d & A.h==h;
    if win==1,idx=idx & A.t==C.T;name='T100';else,name='late80_100';end
    z=A(idx,:);rc=sqrt(mean(z.mse_coarse_reference));rf=sqrt(mean(z.mse_fine_reference));rr=sqrt(mean(z.reference_mse));
    rows(end+1,:)={C.methods{m},d,h,name,rc,rf,100*(rc/rf-1),rr,100*rr/rf}; %#ok<AGROW>
   end
  end
 end
end
Q=cell2table(rows,'VariableNames',{'method','d','h','window','rms_ref_h','rms_ref_half_h','relative_percent','reference_difference_rms','reference_difference_relative_percent'});
writetable(Q,fullfile(outdir,'reference_check.csv'));result=Q;
end

function result=test_algorithms()
rng(18423,'twister');N=9;d=5;h=2^-11;Y=randn(N,d);dW=sqrt(h)*randn(N,d);
[Z,~,res]=implicit_stage(Y,h);assert(res<=1e-12);
p=randperm(N);Zp=implicit_stage(Y(p,:),h);
assert(max(abs(reshape(Zp-Z(p,:),[],1)))<1e-10);
A=pm_step(Y,dW,h,1/8);B=pm_step(Y(p,:),dW(p,:),h,1/8);
assert(max(abs(reshape(B-A(p,:),[],1)))<1e-12);
% Antisymmetry when state, drift mean, and Brownian path are sign-reversed.
B=pm_step(-Y,-dW,h,1/8);assert(max(abs(A(:)+B(:)))<1e-12);
% Nonzero diagonal Milstein coefficient: g'(u)g(u)=u.
u=randn(100,1);g=sqrt(1+u.^2);assert(max(abs((u./g).*g-u))<1e-14);
% Cross-dimensional radial projection must NOT be treated as a prefix.
y=ones(1,8);y2=y(1:2);rad=1.5;
p8=y*min(1,rad/norm(y));p2=y2*min(1,rad/norm(y2));assert(norm(p8(1:2)-p2)>.1);
result=true;disp('All algebra and implementation tests passed.');
end
