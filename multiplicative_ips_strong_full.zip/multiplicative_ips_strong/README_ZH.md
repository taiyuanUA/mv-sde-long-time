# 三次漂移与乘性噪声：SSBE / PM 相对于同一 IPS 的长时间强误差

## 实验范围与运行状态

这是一个全新的时间离散实验，不是前面的混沌传播数据，也不是改变粒子数的自收敛实验。
模型为

\[
 dX_t=[-2X_t-14X_t^{[3]}+\tfrac12\mathbb EX_t]dt
      +\operatorname{diag}(\sqrt{1+X_{t,1}^2},\ldots,\sqrt{1+X_{t,d}^2})dW_t,
 \quad X_0\sim N(0,I_d).
\]

所有参考和待测解均为 N=64 的完整相互作用系统。所有层级均计算自身的随机经验均值，不能用极限均值零代替。

主实验参数：T=100，R=16 个独立完整系统，d=2,3,4,5,8；六个测试步长 h=2^-11,...,2^-16。
投影参数 alpha=1/8。主参考步长 2^-17，参考审计另用 2 个独立系统比较 2^-17 和 2^-18。
在整数时刻 0,1,...,100 保存误差；辅助窗口为整数时刻 80,...,100。

- 实际数值核：verification/run.cpp，以 g++ -O3 -march=native -fopenmp -std=c++17 编译。
- C++ 随机数：mt19937_64 + Boost normal_distribution；每个完整系统独立种子。
- 主种子：202609302713；第 r 个系统加上 1000003*r（r从0开始）。
- 审计种子：202609303719，采用同样的系统编号规则。
- MATLAB 文件实现相同的数值算法；本环境没有 MATLAB/Octave，不声称在 MATLAB 解释器中执行过。
- MATLAB 与 C++ 的随机数序列不同，因此重新模拟不应逐位复现归档误差。
- 不缩短时间区间、不将早期细网格换成粗网格、不从平衡分布重新初始化、不排除样本或误差点。
- bootstrap 使用完整系统为重采样单位。不同步长和维数共享随机输入，不能当作彼此独立的实验。

## 1. 假设1--5的参数验证

设 m(mu)=int y mu(dy)，g(u)=sqrt(1+u^2)。
对于任意 u,v,

\[
 |g(u)-g(v)|^2
 =\frac{(u-v)^2(u+v)^2}{(\sqrt{1+u^2}+\sqrt{1+v^2})^2}
 \le\tfrac13(u^2+uv+v^2)(u-v)^2.
\]

又 |g'|<=1，g''(u)=(1+u^2)^(-3/2)<=1。
取 q0=80，kappa=3，利用 28-79/3=5/3>0，负三次漂移吸收扩散差的高阶贡献：

\[
 2\langle x-y,b(x,\mu)-b(y,\nu)\rangle
 +79\|S(x)-S(y)\|^2
 \le-\tfrac72|x-y|^2+\tfrac12 W_2(\mu,\nu)^2.
\]

可取 K1=7/2,K2=1/2。
漂移局部Lipschitz可取 L=2646，b(0,delta0)=0。
由 79z^2-28z^4<=79^2/112，且 79+79^2/112<135，可取 a1=7/2,a2=1/2,C0=135d。
扩散全局Lipschitz可取 L_sigma=1。

Milstein正则性：

\[
 D_xb=-2I_d-42\operatorname{diag}(x_1^2,\ldots,x_d^2),\quad
 D^2_{xx}b[u,v]=-84(x_lu_lv_l)_{l=1}^d,\quad D^Lb(v)=\tfrac12I_d.
\]

漂移的二阶测度导数、评价变量导数和空间--测度混合导数均为零。

\[
 D_x\sigma_s=\frac{x_s}{\sqrt{1+x_s^2}}e_se_s^\top,\quad
 D_{xx}^2\sigma_s[u,v]=(1+x_s^2)^{-3/2}u_sv_se_s,\quad D^L\sigma_s=0.
\]

诱导算子范数下，\(\mathfrak Db\le2.5+42|x|^2+84|x|\le84(1+|x|^2)\)，且 \(\mathfrak D\sigma_s\le2\)。局部导数差由 |g''|<=1 控制。
因此 C_M=84 可用。若用 Frobenius 范数，可取 max{84,42+2.5sqrt(d)}；在所测五个维数仍可统一取84。

alpha=1/8 满足 alpha(kappa-1)=1/4<1/3；p_SSBE=14，p_PM=max(18,4+8/alpha)=68，均<=q0=80。

这些是系数、正则性和矩阶的验证。本实验不声称已将保守的通用 h_mom 常数逐项数值化并验证所有测试步长低于该通用上限；有限网格观测不代替无限时间证明。

## 2. 两个数值格式

SSBE 完整耦合隐式阶段：

\[
 (1+2h)z_i+14hz_i^{[3]}-\tfrac h{2N}\sum_j z_j=y_i,
 \quad y_i^+=z_i+S(z_i)\Delta W_i.
\]

Newton Jacobian 为对角减去秩一矩阵；用 Sherman--Morrison 形式解每次 Newton 线性系统，归一化残差要求 1e-12；未收敛就报错，不静默返回。

PM：

\[
 z_i=\min\{1,h^{-1/8}/|y_i|\}y_i,
 \quad y_i^+=z_i+h[-2z_i-14z_i^{[3]}+\tfrac12\bar z]
       +S(z_i)\Delta W_i+\tfrac12 z_i\odot[(\Delta W_i)^{\odot2}-h\mathbf1].
\]

这里 S(x)非恒定，且 g'(x)g(x)=x；Milstein修正严格非零。扩散无测度依赖，因此其 Lions 修正为零。不同噪声列可交换，未近似非对角Levy面积。
SSBE和参考可用八维坐标前缀；PM必须对每个维数独立执行径向投影并推进自己的状态，代码确实如此。

## 3. 高阶参考的明确公式

固定参考步delta，令（逐坐标）

\[
 B_i=-2x_i-14x_i^{[3]}+\tfrac12\bar x,\quad
 g_i=\sqrt{1+x_i^{\odot2}},\quad b_i'=-2-42x_i^{\odot2}.
\]

\[
 L_0 B_i=b_i'\odot B_i+\tfrac12\overline B-42x_i\odot(\mathbf1+x_i^{\odot2}),
 \quad L_0g_i=(x_i\odot B_i+\tfrac12\mathbf1)\oslash g_i.
\]

其中 oslash 为逐坐标除法。
生成 w_i=sqrt(delta)G1_i，J_i=delta*w_i/2+sqrt(delta^3/12)G2_i；G1,G2独立标准正态。
J 对应 int_t^(t+delta)(t+delta-u)dW_u；Var(J)=delta^3/3，Cov(w,J)=delta^2/2。
参考更新：

\[
\begin{aligned}
 x_i^+={}&x_i+\delta B_i+g_i\odot w_i+\tfrac12x_i\odot(w_i^{\odot2}-\delta\mathbf1)
 +\tfrac12\delta^2 L_0B_i\\
 &+b_i'\odot g_i\odot J_i+\tfrac1{2N}\sum_jg_j\odot J_j
 +(L_0g_i)\odot(\delta w_i-J_i)
 +\tfrac16g_i\odot(w_i^{\odot3}-3\delta w_i).
\end{aligned}
\]

关键：mean(g*J)/2 是测度依赖漂移引出的项，不能漏掉。
这是 Ito--Taylor 权重1.5展开（含确定性二阶项）的参考算法，而非精确路径。本例没有另证该未投影参考的全局无限时间误差定理，因此明确进行网格加密检查。

两个半步合并的严格同步方式为 w=w1+w2，J=J1+delta_fine*w1+J2。
所有粗方法 Brownian 增量都由相应细步 w 累加，初值完全相同。

## 4. 统计量与结果文件

每次完整系统计算 A_(r,h,d)(t)=N^-1 sum_i |Y_(t/h)^(i,N,r)-X_t^(i,N,ref,r)|^2。
图中画 sqrt(mean_r A)，不是 mean_r sqrt(A)，也不是与极限MV-SDE之间的总误差。
六个h全部用于 log误差对logh 的普通最小二乘拟合；未固定拟合阶、未删点。
绿色虚线是独立的理论参考线，可做固定竖直平移；它不是模拟数据或误差上界。

- data/raw_observations.csv: 逐系统、时刻、方法、维数、步长的真实平方误差。
- data/raw_projection.csv: 全时间和[80,100]投影触发数。
- data/solver_diagnostics.csv: Newton残差、迭代数、参考状态最大值。
- data/summary.csv: 主图数值，终端与窗口RMS。
- data/rates.csv: 全六点回归、5000次完整系统bootstrap区间、窗口斜率、最细两步相邻阶。
- data/checkpoint_rates.csv: 多个终止时刻的六点拟合。
- audit/raw_audit.csv, audit/reference_check.csv: 同N、同步参考步长减半检查。

参考审计只有2个完整系统，属于确定误差量级的辅助数值检查，不作为精确总体参考偏差上界。
图的最终数值和投影触发状况以数据表为准，不从理论阶生成。

## 5. MATLAB运行

```matlab
addpath('matlab');
multiplicative_ips_strong('plot');  % 只根据归档数据重画图
multiplicative_ips_strong('test');
multiplicative_ips_strong('simulate','my_results',16);
multiplicative_ips_strong('analyze','my_results');
multiplicative_ips_strong('audit','my_audit',2);
```

仅用MATLAB基本函数。simulate昂贵；plot无需重新做模拟。程序返回PNG、矢量PDF及MATLAB原生.fig（.fig需在MATLAB中运行plot生成，本包不伪造.fig）。

## 6. 来源与自行推导的界限

文献中的组织思路是同步耦合、细步参考与终端均方根误差。具体模型的参数验证、参考算子的展开和本次数据是本实验自行计算的，不是引用文献中的实验数据。

- Chen and dos Reis, A flexible split-step scheme for solving McKean--Vlasov stochastic differential equations, Applied Mathematics and Computation 427 (2022), 127180. doi:10.1016/j.amc.2022.127180.
- Chen and dos Reis, Euler simulation of interacting particle systems and McKean--Vlasov SDEs with fully super-linear growth drifts in space and interaction, IMA Journal of Numerical Analysis 44 (2024), 751--796. doi:10.1093/imanum/drad022.
- Beyn, Isaak and Kruse, Stochastic C-stability and B-consistency of explicit and implicit Milstein-type schemes, Journal of Scientific Computing 70 (2017), 1042--1077. doi:10.1007/s10915-016-0290-x.

上述文献不等同于当前稿件的无限时间定理，也不为本次实测斜率提供数据。

### 本轮实际 C++ 命令

```bash
g++ -O3 -march=native -fopenmp -std=c++17 verification/run.cpp -o verification/run
./verification/run main data 16 64 11 17 100 4 202609302713
./verification/run audit audit 2 64 11 17 100 1 202609303719
```

命令参数依次指定输出目录、重复系统数、粒子数、最粗步长指数、参考步长指数、终止时间、线程数和主种子。MATLAB文件中的默认配置与这组明确参数相同。

## 8. 本轮完整运行结果

主运行已完成16个独立完整IPS；每个包含64个八维粒子，PM各维另设正确的径向投影系统。主运行日志的 wall_seconds=1479.65。参考审计的两个独立完整系统亦已完成。所有误差均由新模拟得到。

|d|SSBE 六点斜率|PM 六点斜率|SSBE 最细两点相邻阶|PM 最细两点相邻阶|
|---:|---:|---:|---:|---:|
|2|0.568435|1.014027|0.502396|0.991128|
|3|0.565967|1.010698|0.522496|1.007340|
|4|0.564366|1.007281|0.524653|1.013502|
|5|0.563061|1.005335|0.521428|1.005762|
|8|0.562381|1.003897|0.528183|1.004685|

SSBE 的六点斜率约0.56，不是恰好0.5；最细两点的相邻阶为0.502--0.528，支持趋近半阶的解释。PM六点斜率为1.004--1.014，呈清楚的一阶趋势。没有舍弃粗步点或把斜率固定为理论值。

参考步长由2^(-17)减半到2^(-18)，终端误差相对变化的最大绝对值为0.01410627%；同时包括窗口时，最大两级参考RMS差占被测误差的0.304478%。这是两级诊断，不是参考误差的严格上界。

PM全区间的投影次数（汇总六个步长、16个独立系统）依d=2,3,4,5,8为101, 240, 435, 718, 2259；[80,100]阶段各维均未观测到投影。这不表示投影算子被删除，主程序始终执行投影。

主CSV含96960条误差观测，参考审计含2520条记录，均通过完整性与有限值检查。完整包保留参数、原始误差、实际C++源码和运行日志；MATLAB程序是同算法独立实现，当前环境未运行MATLAB。
