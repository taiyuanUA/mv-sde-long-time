"""Algebra checks, not trajectory experiments; require only numpy."""
import json
from pathlib import Path
import numpy as np
out=Path(__file__).resolve().parent
rng=np.random.default_rng(71138)
N,d=7,3
x=rng.normal(size=(N,d))*.4
mu=x.mean(axis=0)
b=-2*x-14*x**3+.5*mu
g=np.sqrt(1+x*x)
bp=-2-42*x*x
L0b=bp*b+.5*b.mean(axis=0)-42*x*(1+x*x)
L0g=(x*b+.5)/g

def drift(z): return -2*z-14*z**3+.5*z.mean(axis=0)

# Directional first and second derivatives on the full particle vector.
eps=2e-4
err_L0b=0.
H=0.
for j in range(N):
 for q in range(d):
  v=np.zeros_like(x);v[j,q]=g[j,q]
  H=H+.5*(drift(x+eps*v)-2*drift(x)+drift(x-eps*v))/(eps**2)
L0b_num=(drift(x+eps*b)-drift(x-eps*b))/(2*eps)+H
err_L0b=float(np.max(np.abs(L0b_num-L0b)))
assert err_L0b<2e-3
# Exact directional Jacobian and L0g.
v=rng.normal(size=x.shape)
exact=bp*v+.5*v.mean(axis=0)
err_db=float(np.max(np.abs((drift(x+1e-6*v)-drift(x-1e-6*v))/(2e-6)-exact)))
assert err_db<1e-7
u=rng.normal(size=20000)*4;v1=rng.normal(size=20000)*4
gdiff=(np.sqrt(1+u*u)-np.sqrt(1+v1*v1))**2
rhs=(u*u+u*v1+v1*v1)*(u-v1)**2/3
assert np.all(gdiff<=rhs+1e-12)
# Simultaneous permutation equivariance of drift and PM (with own radius in each d).
xp=rng.normal(size=(N,d))*2;w=rng.normal(size=(N,d))*.01;h=1/2048

def pm(z,w):
 norms=np.linalg.norm(z,axis=1);z=z*np.minimum(1.,h**(-1/8)/np.maximum(norms,1e-300))[:,None]
 return z+h*drift(z)+np.sqrt(1+z*z)*w+.5*z*(w*w-h)
p=rng.permutation(N)
err_eq=float(np.max(np.abs(pm(xp[p],w[p])-pm(xp,w)[p])))
assert err_eq<1e-14
# Boundary/noise conventions and paired time-noise integral.
a,bg,cg,dg=rng.normal(size=(4,200000));dt=1/1024
dw1=np.sqrt(dt)*a;dw2=np.sqrt(dt)*bg
j1=.5*dt*dw1+np.sqrt(dt**3/12)*cg
j2=.5*dt*dw2+np.sqrt(dt**3/12)*dg
wc=dw1+dw2;jc=j1+dt*dw1+j2
var_w=float(np.var(wc)/(2*dt));var_j=float(np.var(jc)/((2*dt)**3/3));cov=float(np.mean(wc*jc)/((2*dt)**2/2))
assert abs(var_w-1)<.015 and abs(var_j-1)<.015 and abs(cov-1)<.015
result=dict(drift_directional_error=err_db,L0b_finite_difference_error=err_L0b,PM_permutation_error=err_eq,aggregated_w_variance_ratio=var_w,aggregated_J_variance_ratio=var_j,aggregated_covariance_ratio=cov,tests_passed=True)
(out/'algebra_checks.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
