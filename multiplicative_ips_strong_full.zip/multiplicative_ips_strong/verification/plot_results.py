"""Redraw two separate plots from observed summary data; do not synthesize data."""
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
root=Path(__file__).resolve().parents[1];out=root/'figures';out.mkdir(exist_ok=True)
S=pd.read_csv(root/'data/summary.csv')
dims=[2,3,4,5,8]
colors=[(.55,.33,.29),(.86,.43,.74),(.43,.43,.43),(.60,.60,0),(.05,.45,.75)]
marks=['D','s','o','v','x']
plt.rcParams.update({'font.size':12,'axes.titlesize':17,'axes.labelsize':16,'pdf.fonttype':42,'ps.fonttype':42})
for method,order in [('SSBE',.5),('PM',1.)]:
    z=S[S.method==method];H=np.sort(z.h.unique());hd=np.geomspace(H[0],H[-1],240)
    fig=plt.figure(figsize=(10,7));ax=fig.add_axes([.14,.14,.83,.76])
    coef=1.4*np.max(z.rms/z.h**order)
    ax.loglog(hd,coef*hd**order,'--',color=(0,.6,.15),lw=1.8)
    handles=[Line2D([],[],color=(0,.6,.15),ls='--',lw=1.8,label=f'Reference slope {order:g}')]
    for d,c,m in zip(dims,colors,marks):
        y=z[z.d==d].sort_values('h');p=np.polyfit(np.log(y.h),np.log(y.rms),1)
        ax.loglog(hd,np.exp(np.polyval(p,np.log(hd))),color=c,lw=1.4)
        ax.loglog(y.h,y.rms,ls='none',marker=m,color=c,markersize=6.5,mew=1.2)
        handles.append(Line2D([],[],color=c,lw=1.4,marker=m,markersize=6.5,label=f'd={d}, slope={p[0]:.3f}'))
    ax.set_title(f'The Strong Convergence Rate of {method}',pad=12)
    ax.set_xlabel('Step size $h$');ax.set_ylabel(r'$\widehat e_{h,d}(T)$')
    ax.legend(handles=handles,loc='upper left',fontsize=11,framealpha=1,fancybox=False)
    ax.set_xlim(H[0]/1.3,H[-1]*1.2)
    ax.tick_params(which='both',direction='in',top=True,right=True)
    ax.grid(False)
    fig.savefig(out/f'multiplicative_{method}_strong.png',dpi=250)
    fig.savefig(out/f'multiplicative_{method}_strong.pdf')
    plt.close(fig)
print('Two separate figures regenerated from all six observed errors in each dimension.')
