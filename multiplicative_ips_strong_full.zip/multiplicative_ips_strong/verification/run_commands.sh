#!/usr/bin/env bash
# Run from the experiment root. Requires g++ and Boost headers.
set -euo pipefail
mkdir -p data audit
g++ -O3 -march=native -fopenmp -std=c++17 verification/run.cpp -o verification/run
./verification/run main data 16 64 11 17 100 4 202609302713 | tee verification/main.log
./verification/run audit audit 2 64 11 17 100 1 202609303719 | tee verification/audit.log
python verification/test_algebra.py
python verification/analyze.py
# The supplied MATLAB entry point is an independent alternative and
# does not require this C++/Python verification toolchain.
