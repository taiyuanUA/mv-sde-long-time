#define main archived_driver_main
#include "run.cpp"
#undef main
#include <cassert>
int main(){
 int N=7,d=3;double h=1./2048;V y(N*d),w(N*d);std::mt19937_64 rng(1367);boost::random::normal_distribution<double> normal;
 for(int k=0;k<N*d;++k){y[k]=normal(rng);w[k]=std::sqrt(h)*normal(rng);}
 V z=y,zero(N*d,0);Stage diag;ssbe(z,zero,N,d,h,diag);double worst=0;
 for(int q=0;q<d;++q){double mean=0;for(int i=0;i<N;++i)mean+=z[q*N+i];mean/=N;for(int i=0;i<N;++i){int k=q*N+i;worst=std::max(worst,std::abs((1+2*h)*z[k]+14*h*z[k]*z[k]*z[k]-.5*h*mean-y[k]));}}
 assert(worst<1e-10);
 V a=y;ssbe(a,w,N,d,h,diag);std::array<int,7> perm={5,3,0,6,1,2,4};V yp(N*d),wp(N*d);
 for(int q=0;q<d;++q)for(int i=0;i<N;++i){yp[q*N+i]=y[q*N+perm[i]];wp[q*N+i]=w[q*N+perm[i]];}
 ssbe(yp,wp,N,d,h,diag);double equiv=0;for(int q=0;q<d;++q)for(int i=0;i<N;++i)equiv=std::max(equiv,std::abs(yp[q*N+i]-a[q*N+perm[i]]));assert(equiv<1e-12);
 V xs={.37},ws={.014},js={2e-6};double b=-1.5*xs[0]-14*std::pow(xs[0],3),bp=-1.5-42*xs[0]*xs[0],g=std::sqrt(1+xs[0]*xs[0]);
 double scalar=xs[0]+h*b+g*ws[0]+.5*xs[0]*(ws[0]*ws[0]-h)+.5*h*h*(bp*b-42*xs[0]*g*g)+bp*g*js[0]+((xs[0]*b+.5)/g)*(h*ws[0]-js[0])+g/6*(std::pow(ws[0],3)-3*h*ws[0]);
 double refmax=0;reference(xs,ws,js,1,1,h,refmax);assert(std::abs(xs[0]-scalar)<1e-15);
 uint64_t hits=0,late=0;double mx=0;V large={10,10,10};V nowind(3,0);pm(large,nowind,1,3,h,.125,hits,late,0,mx);assert(hits==1);
 std::cout<<std::setprecision(17)<<"PASS SSBE residual="<<worst<<" permutation_error="<<equiv<<" scalar_reference_error="<<std::abs(xs[0]-scalar)<<"\n";
}
