"""Statistics from actual complete-system data. Fits are unconstrained."""
from pathlib import Path
import numpy as np
import pandas as pd
import json
root=Path(__file__).resolve().parents[1]
S=pd.read_csv(root/'data/raw_observations.csv')
R=S.system.nunique(); expected=16
if R!=expected or S.t.max()!=100:
    raise RuntimeError(f'Incomplete main run: {R} systems, T={S.t.max()}')
assert len(S)==R*101*2*5*6
assert S.groupby(['system','t','method','d','h']).size().eq(1).all()
assert np.isfinite(S.mse).all() and (S.mse>=0).all()
summary=[];rates=[];adjacent=[];times=[]
rng=np.random.default_rng(314159)
W=rng.multinomial(R,np.full(R,1/R),size=5000)/R
for (m,d),z in S.groupby(['method','d']):
    A=z[z.t==100].pivot(index='system',columns='h',values='mse').sort_index().sort_index(axis=1)
    B=z[z.t>=80].groupby(['system','h']).mse.mean().unstack().reindex(index=A.index,columns=A.columns)
    H=A.columns.to_numpy(float);a=A.to_numpy();b=B.to_numpy()
    x=np.log(H); xc=x-x.mean();y=.5*np.log(a.mean(axis=0));late=.5*np.log(b.mean(axis=0))
    slope,intercept=np.polyfit(x,y,1)
    boot=.5*np.log(W@a)@xc/(xc@xc)
    ci=np.quantile(boot,[.025,.975]);bs=np.polyfit(x,late,1)[0]
    local=np.diff(y)/np.diff(x)
    rates.append([m,d,slope,ci[0],ci[1],bs,local[0]])
    for l,h in enumerate(H):
        avg=a[:,l].mean(); se=a[:,l].std(ddof=1)/np.sqrt(R)
        summary.append([m,d,h,avg,np.sqrt(avg),np.sqrt(b[:,l].mean()),np.sqrt(max(0,avg-1.96*se)),np.sqrt(avg+1.96*se)])
    for l in range(5): adjacent.append([m,d,H[l],H[l+1],local[l]])
    for t,zt in z.groupby('t'):
        for h,q in zt.groupby('h'):times.append([m,d,h,t,np.sqrt(q.mse.mean())])
U=pd.DataFrame(summary,columns=['method','d','h','mse','rms','late_rms','ci_low','ci_high']);U.to_csv(root/'data/summary.csv',index=False)
Q=pd.DataFrame(rates,columns=['method','d','slope','ci_low','ci_high','late_slope','finest_adjacent_order']);Q.to_csv(root/'data/rates.csv',index=False)
pd.DataFrame(adjacent,columns=['method','d','h_fine','h_coarse','adjacent_order']).to_csv(root/'data/adjacent_orders.csv',index=False)
pd.DataFrame(times,columns=['method','d','h','t','rms']).to_csv(root/'data/time_summary.csv',index=False)
P=pd.read_csv(root/'data/raw_projection.csv');pp=[]
for (d,h),z in P.groupby(['d','h']):
    hits=int(z.hits.sum());latehits=int(z.late_hits.sum());updates=int(z.updates.sum());lateupdates=int(z.late_updates.sum())
    pp.append([d,h,hits,updates,100*hits/updates,latehits,lateupdates,100*latehits/lateupdates,z.max_preprojection_norm.max()])
pd.DataFrame(pp,columns=['d','h','hits','updates','hit_percent','late_hits','late_updates','late_hit_percent','max_preprojection_norm']).to_csv(root/'data/projection_summary.csv',index=False)
checkpoints=[]
for t in [1,10,20,50,80,100]:
 for (m,d),z in S[S.t==t].groupby(['method','d']):
    v=z.groupby('h').mse.mean();checkpoints.append([t,m,d,np.polyfit(np.log(v.index),.5*np.log(v.values),1)[0]])
pd.DataFrame(checkpoints,columns=['t','method','d','slope']).to_csv(root/'data/checkpoint_rates.csv',index=False)
# Reference audit uses independent systems and exactly paired Brownian integrals.
raw=root/'audit/raw_audit.csv'
if raw.exists():
    a=pd.read_csv(raw)
    if a.system.nunique()!=2 or len(a)!=2*21*2*5*6:raise RuntimeError('Incomplete audit')
    rows=[]
    for name,z in [('T100',a[a.t==100]),('late80_100',a[a.t>=80])]:
      for (m,d,h),q in z.groupby(['method','d','h']):
        rc=np.sqrt(q.mse_coarse_reference.mean());rf=np.sqrt(q.mse_fine_reference.mean());er=np.sqrt(q.reference_mse.mean())
        rows.append([m,d,h,name,rc,rf,100*(rc/rf-1),er,100*er/rf])
    ad=pd.DataFrame(rows,columns=['method','d','h','window','rms_ref_h','rms_ref_half_h','relative_percent','reference_difference_rms','reference_difference_relative_percent'])
    ad.to_csv(root/'audit/reference_check.csv',index=False)
    print('Max reference metric relative change (%):',ad.relative_percent.abs().max())
    print('Max reference two-level gap / metric (%):',ad.reference_difference_relative_percent.abs().max())
print(Q.to_string(index=False))
print('Projection: ',pd.read_csv(root/'data/projection_summary.csv')[['d','hits','late_hits']].groupby('d').sum().to_string())
D=pd.read_csv(root/'data/solver_diagnostics.csv');print(D.max(numeric_only=True))
(root/'verification/completion.json').write_text(json.dumps({'main_systems':int(R),'N':64,'T':100,'six_stepsizes':sorted(U.h.unique().tolist()),'alpha':.125,'reference_step':2**-17,'audit_systems':2,'full_interval':True,'discarded_systems':0,'discarded_points':0},indent=2))
