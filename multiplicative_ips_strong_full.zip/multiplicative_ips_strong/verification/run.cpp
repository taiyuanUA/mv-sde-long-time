#include <boost/random/normal_distribution.hpp>
// Actual same-N IPS simulations. No truncation of the simulation horizon,
// no empirical centering, no removal or alteration of observations.
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
#include <omp.h>
using V=std::vector<double>;
const int D=8,L=6; const std::array<int,5> dims={2,3,4,5,8};
struct Stage {double maxres=0; int maxit=0;};
void ssbe(V &y,const V &dw,int N,int d,double h,Stage &diag){
 V z(N),F(N),inv(N),gg(N); double a=1+2*h,c=.5*h,b=14*h;
 for(int q=0;q<d;++q){int off=q*N;double scale=1;
 for(int i=0;i<N;++i){z[i]=y[off+i];scale=std::max(scale,1+std::abs(z[i]));}
 bool ok=false;
 for(int it=0;it<=15;++it){double mean=0;for(double x:z)mean+=x;mean/=N;double mr=0;
 for(int i=0;i<N;++i){F[i]=(a+b*z[i]*z[i])*z[i]-c*mean-y[off+i];mr=std::max(mr,std::abs(F[i])/scale);}
 if(mr<=1e-12){diag.maxres=std::max(diag.maxres,mr);diag.maxit=std::max(diag.maxit,it);ok=true;break;}
 double si=0,sg=0;for(int i=0;i<N;++i){inv[i]=1/(a+3*b*z[i]*z[i]);gg[i]=inv[i]*F[i];si+=inv[i];sg+=gg[i];}
 double corr=c*(sg/N)/(1-c*(si/N));for(int i=0;i<N;++i)z[i]-=gg[i]+inv[i]*corr;}
 if(!ok)throw std::runtime_error("Newton did not converge");
 for(int i=0;i<N;++i){double value=z[i]+std::sqrt(1+z[i]*z[i])*dw[off+i];if(!std::isfinite(value))throw std::runtime_error("SSBE nonfinite");y[off+i]=value;}}
}
void pm(V &y,const V &dw,int N,int d,double h,double alpha,uint64_t &hits,uint64_t &latehits,double time,double &maxnorm){
 V mean(d,0.0);double radius=std::pow(h,-alpha);
 for(int i=0;i<N;++i){double n2=0;for(int q=0;q<d;++q)n2+=y[q*N+i]*y[q*N+i];double norm=std::sqrt(n2);maxnorm=std::max(maxnorm,norm);double factor=std::min(1.,radius/std::max(norm,1e-300));if(factor<1){++hits;if(time>=80)++latehits;}for(int q=0;q<d;++q){y[q*N+i]*=factor;mean[q]+=y[q*N+i];}}
 for(int q=0;q<d;++q){double m=mean[q]/N;for(int i=0;i<N;++i){int k=q*N+i;double x=y[k],w=dw[k];y[k]=x+h*(-2*x-14*x*x*x+.5*m)+std::sqrt(1+x*x)*w+.5*x*(w*w-h);if(!std::isfinite(y[k]))throw std::runtime_error("PM nonfinite");}}
}
// Strong Itô--Taylor 1.5 expansion, including deterministic order two.
// This is a numerical reference, not an exact solution.
void reference(V &x,const V &w,const V &J,int N,int d,double dt,double &maxabs){
 V b(N),g(N);for(int q=0;q<d;++q){int off=q*N;double mean=0;for(int i=0;i<N;++i)mean+=x[off+i];mean/=N;double mb=0,mgj=0;
 for(int i=0;i<N;++i){double u=x[off+i];b[i]=-2*u-14*u*u*u+.5*mean;g[i]=std::sqrt(1+u*u);mb+=b[i];mgj+=g[i]*J[off+i];}mb/=N;mgj/=N;
 for(int i=0;i<N;++i){int k=off+i;double u=x[k],dw=w[k],j=J[k],bp=-2-42*u*u;double L0b=bp*b[i]+.5*mb-42*u*(1+u*u);double L0g=(u*b[i]+.5)/g[i];
 double val=u+dt*b[i]+g[i]*dw+.5*u*(dw*dw-dt)+.5*dt*dt*L0b+bp*g[i]*j+.5*mgj+L0g*(dt*dw-j)+(g[i]/6)*(dw*dw*dw-3*dt*dw);
 if(!std::isfinite(val)||std::abs(val)>1e6)throw std::runtime_error("Unstable reference: no reset performed");x[k]=val;maxabs=std::max(maxabs,std::abs(val));}}
}
struct Result {std::vector<std::array<double,5>> records;std::array<uint64_t,30>hits{},latehits{};std::array<double,30>maxnorm{};Stage stage;double refmax=0;};
Result one(int r,int N,int first,int refK,double T,double alpha,uint64_t seed){
 Result out;int nr=std::llround(std::ldexp(T,refK));double dt=std::ldexp(1.,-refK),sd=std::sqrt(dt),sj=std::sqrt(dt*dt*dt/12);std::array<double,L>hs;std::array<int,L>ratio;
 std::mt19937_64 rng(seed+UINT64_C(1000003)*r);boost::random::normal_distribution<double>normal;V x(N*D),w(N*D),J(N*D);for(double &a:x)a=normal(rng);
 std::array<V,L> ys,acc;std::array<V,30>yp;
 for(int l=0;l<L;++l){hs[l]=std::ldexp(1.,-first-l);ratio[l]=1<<(refK-first-l);ys[l]=x;acc[l]=V(N*D,0);for(int di=0;di<5;++di)yp[di*L+l]=V(x.begin(),x.begin()+N*dims[di]);}
 int save=1<<refK;
 auto record=[&](double t){for(int method=0;method<2;++method)for(int di=0;di<5;++di)for(int l=0;l<L;++l){const V &y=method==0?ys[l]:yp[di*L+l];double mse=0;for(int k=0;k<N*dims[di];++k){double e=y[k]-x[k];mse+=e*e;}out.records.push_back({t,(double)method,(double)dims[di],hs[l],mse/N});}};record(0);
 for(int n=1;n<=nr;++n){for(int k=0;k<N*D;++k){w[k]=sd*normal(rng);J[k]=.5*dt*w[k]+sj*normal(rng);}reference(x,w,J,N,D,dt,out.refmax);
 for(int l=0;l<L;++l){for(int k=0;k<N*D;++k)acc[l][k]+=w[k];if(n%ratio[l]==0){ssbe(ys[l],acc[l],N,D,hs[l],out.stage);for(int di=0;di<5;++di){int idx=di*L+l;pm(yp[idx],acc[l],N,dims[di],hs[l],alpha,out.hits[idx],out.latehits[idx],n*dt,out.maxnorm[idx]);}std::fill(acc[l].begin(),acc[l].end(),0);}}
 if(n%save==0)record(n*dt);}
 return out;
}
void run_audit(int R,int N,int first,int refK,double T,double alpha,uint64_t seed,const std::string &path){
 std::filesystem::create_directories(path);std::ofstream f(path+"/raw_audit.csv");f<<"system,t,method,d,h,mse_coarse_reference,mse_fine_reference,reference_mse\n"<<std::setprecision(17);
 for(int r=0;r<R;++r){std::mt19937_64 rng(seed+UINT64_C(1000003)*r);boost::random::normal_distribution<double>normal;V fine(N*D),coarse;for(double &a:fine)a=normal(rng);coarse=fine;
 std::array<V,L>ys,acc;std::array<V,30>yp;std::array<double,L>hs;std::array<int,L>ratio;
 for(int l=0;l<L;++l){hs[l]=std::ldexp(1.,-first-l);ratio[l]=1<<(refK-first-l);ys[l]=fine;acc[l]=V(N*D,0);for(int di=0;di<5;++di)yp[di*L+l]=V(fine.begin(),fine.begin()+N*dims[di]);}
 double dt=std::ldexp(1.,-refK),dd=dt/2,sd=std::sqrt(dd),sj=std::sqrt(dd*dd*dd/12),refmax=0,maxnorm=0;V w1(N*D),w2(N*D),j1(N*D),j2(N*D),w(N*D),J(N*D);Stage stage;uint64_t hits=0,latehits=0;int nr=std::llround(T/dt);
 for(int n=1;n<=nr;++n){for(int k=0;k<N*D;++k){w1[k]=sd*normal(rng);j1[k]=.5*dd*w1[k]+sj*normal(rng);w2[k]=sd*normal(rng);j2[k]=.5*dd*w2[k]+sj*normal(rng);w[k]=w1[k]+w2[k];J[k]=j1[k]+dd*w1[k]+j2[k];}
 reference(fine,w1,j1,N,D,dd,refmax);reference(fine,w2,j2,N,D,dd,refmax);reference(coarse,w,J,N,D,dt,refmax);
 for(int l=0;l<L;++l){for(int k=0;k<N*D;++k)acc[l][k]+=w[k];if(n%ratio[l]==0){ssbe(ys[l],acc[l],N,D,hs[l],stage);for(int di=0;di<5;++di)pm(yp[di*L+l],acc[l],N,dims[di],hs[l],alpha,hits,latehits,n*dt,maxnorm);std::fill(acc[l].begin(),acc[l].end(),0);}}
 if(n%(1<<refK)==0 && n*dt>=80){for(int method=0;method<2;++method)for(int di=0;di<5;++di)for(int l=0;l<L;++l){auto &y=method==0?ys[l]:yp[di*L+l];double e1=0,e2=0,er=0;for(int k=0;k<N*dims[di];++k){e1+=std::pow(y[k]-coarse[k],2);e2+=std::pow(y[k]-fine[k],2);er+=std::pow(coarse[k]-fine[k],2);}f<<r<<","<<n*dt<<","<<(method==0?"SSBE":"PM")<<","<<dims[di]<<","<<hs[l]<<","<<e1/N<<","<<e2/N<<","<<er/N<<"\n";}}}
 f.flush();std::cout<<"audit "<<r+1<<"/"<<R<<" completed"<<std::endl;}
}
int main(int argc,char**argv){try{
 // mode output R N firstExponent referenceExponent T threads seed
 std::string mode=argc>1?argv[1]:"main",outpath=argc>2?argv[2]:"data";int R=argc>3?std::stoi(argv[3]):32,N=argc>4?std::stoi(argv[4]):128,first=argc>5?std::stoi(argv[5]):8,refK=argc>6?std::stoi(argv[6]):14;double T=argc>7?std::stod(argv[7]):100;int threads=argc>8?std::stoi(argv[8]):4;uint64_t seed=argc>9?std::stoull(argv[9]):202609301731ULL;double alpha=.125;
 if(refK<first+L-1)throw std::runtime_error("Reference grid not nested");omp_set_num_threads(threads);auto st=std::chrono::steady_clock::now();std::cout<<"mode="<<mode<<" R="<<R<<" N="<<N<<" first="<<first<<" ref="<<refK<<" T="<<T<<" seed="<<seed<<std::endl;
 if(mode=="audit"){run_audit(R,N,first,refK,T,alpha,seed,outpath);return 0;}
 std::filesystem::create_directories(outpath);std::ofstream f(outpath+"/raw_observations.csv"),p(outpath+"/raw_projection.csv"),dg(outpath+"/solver_diagnostics.csv");f<<"system,t,method,d,h,mse\n"<<std::setprecision(17);p<<"system,d,h,hits,late_hits,updates,late_updates,max_preprojection_norm\n"<<std::setprecision(17);dg<<"system,max_normalized_residual,max_Newton_updates,reference_max_abs_coordinate\n"<<std::setprecision(17);
 #pragma omp parallel for schedule(dynamic)
 for(int r=0;r<R;++r){auto result=one(r,N,first,refK,T,alpha,seed);
 #pragma omp critical
 {for(auto &a:result.records)f<<r<<","<<a[0]<<","<<(a[1]==0?"SSBE":"PM")<<","<<a[2]<<","<<a[3]<<","<<a[4]<<"\n";
 for(int di=0;di<5;++di)for(int l=0;l<L;++l){int idx=di*L+l;double h=std::ldexp(1.,-first-l);uint64_t updates=std::llround(T/h)*N,lateUpdates=(std::llround(std::max(0.,T-80)/h)+(T>=80))*N;p<<r<<","<<dims[di]<<","<<h<<","<<result.hits[idx]<<","<<result.latehits[idx]<<","<<updates<<","<<lateUpdates<<","<<result.maxnorm[idx]<<"\n";}
 dg<<r<<","<<result.stage.maxres<<","<<result.stage.maxit<<","<<result.refmax<<"\n";f.flush();p.flush();dg.flush();std::cout<<"system "<<r+1<<" completed; elapsed "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-st).count()<<" s"<<std::endl;}}
 std::cout<<"COMPLETE wall_seconds="<<std::chrono::duration<double>(std::chrono::steady_clock::now()-st).count()<<std::endl;return 0;
 }catch(std::exception &e){std::cerr<<e.what()<<std::endl;return 1;}}
