function plot_ips_rates_clean(dataFile,outdir)
% PLOT_IPS_RATES_CLEAN  Replot the archived six-step IPS error estimates.
% Only plotting is performed. No simulation or error-data modification.
%
% Usage:
%   plot_ips_rates_clean
%   plot_ips_rates_clean('summary.csv','figures_clean')
%
% Input columns: method, d, h, and rms (or rmse or mse).
% PM denotes the main experiment with alpha=1/8. The model-specific
% alpha=1/4 supplement is not substituted for the main PM data.

root = fileparts(mfilename('fullpath'));
if nargin < 1 || isempty(dataFile)
    dataFile = fullfile(root,'data','summary.csv');
end
if nargin < 2 || isempty(outdir)
    outdir = fullfile(root,'figures_clean');
end
assert(exist(dataFile,'file') == 2, ...
    'Cannot find the input data file: %s',dataFile);
if ~exist(outdir,'dir'), mkdir(outdir); end
S = readtable(dataFile);
required = {'method','d','h'};
assert(all(ismember(required,S.Properties.VariableNames)), ...
    'The data file must contain method, d, and h columns.');
if ismember('rms',S.Properties.VariableNames)
    valueName = 'rms';
elseif ismember('rmse',S.Properties.VariableNames)
    valueName = 'rmse';
elseif ismember('mse',S.Properties.VariableNames)
    valueName = 'mse';
else
    error('The data file must contain an rms, rmse, or mse column.');
end

methods = {'PM','SSBE'};
dims = [2,3,4,5,8];
colors = [.55 .34 .29; .89 .47 .76; .45 .45 .45; ...
          .66 .65 .10; .10 .43 .78];
markers = {'d','s','o','v','x'};

for a = 1:numel(methods)
    method = methods{a};
    H = [];
    E = zeros(numel(dims),6);
    P = zeros(numel(dims),2);
    for q = 1:numel(dims)
        idx = strcmp(S.method,method) & S.d == dims(q);
        A = sortrows(S(idx,:),'h');
        assert(height(A) == 6 && numel(unique(A.h)) == 6, ...
            '%s, d=%d must have six distinct stepsizes.',method,dims(q));
        values = A.(valueName);
        assert(all(isfinite(A.h) & A.h > 0) && ...
               all(isfinite(values) & values > 0), ...
            'Stepsizes and errors must be finite and strictly positive.');
        if strcmp(valueName,'mse'), values = sqrt(values); end
        if isempty(H)
            H = A.h(:);
        else
            assert(isequal(H,A.h(:)), ...
                'All dimensions must use the same six stepsizes.');
        end
        E(q,:) = values(:).';
        P(q,:) = polyfit(log(H),log(values(:)),1);
    end

    fig = figure('Color','w','Position',[80,80,1000,700]);
    ax = axes('Parent',fig,'Position',[0.14,0.14,0.83,0.76]);
    hold(ax,'on'); box(ax,'on');
    set(ax,'XScale','log','YScale','log', ...
        'FontName','Arial','FontSize',13,'LineWidth',1, ...
        'TickDir','in','XMinorTick','on','YMinorTick','on');
    grid(ax,'off');
    hd = logspace(log10(min(H)),log10(max(H)),240);
    handles = gobjects(6,1);
    labels = cell(6,1);

    % The reference normalization is the same as in the archived plot.
    ref = 1.6*max(E(:,end))/max(H)*hd;
    handles(1) = plot(ax,hd,ref,'--', ...
        'Color',[0,.60,.15],'LineWidth',1.7);
    labels{1} = 'Reference slope 1';

    for q = 1:numel(dims)
        fitValues = exp(polyval(P(q,:),log(hd)));
        plot(ax,hd,fitValues,'-','Color',colors(q,:), ...
            'LineWidth',1.4,'HandleVisibility','off');
        face = colors(q,:);
        if strcmp(markers{q},'x'), face = 'none'; end
        plot(ax,H,E(q,:), ...
            'LineStyle','none','Marker',markers{q}, ...
            'Color',colors(q,:),'MarkerFaceColor',face, ...
            'MarkerSize',7,'LineWidth',1.2,'HandleVisibility','off');
        % A legend-only handle combines the fitted-line and data-marker style.
        handles(q+1) = plot(ax,NaN,NaN,'-', ...
            'Color',colors(q,:),'LineWidth',1.4, ...
            'Marker',markers{q},'MarkerSize',7,'MarkerFaceColor',face);
        labels{q+1} = sprintf('d=%d, slope=%.3f',dims(q),P(q,1));
    end

    title(ax,['The Strong Convergence Rate of ',method], ...
        'Interpreter','none','FontSize',18,'FontWeight','normal');
    xlabel(ax,'Step size $h$','Interpreter','latex','FontSize',16);
    ylabel(ax,'$\widehat{e}_{h,d}(T)$', ...
        'Interpreter','latex','FontSize',18);
    legend(ax,handles,labels,'Interpreter','none', ...
        'Location','northwest','FontSize',11,'Box','on');
    xlim(ax,[min(H)/1.35,max(H)*1.18]);

    % Deliberately no footer, subtitle, annotation, or parameter text.
    set(fig,'PaperUnits','inches','PaperPosition',[0,0,10,7], ...
        'PaperSize',[10,7]);
    stem = fullfile(outdir,[method,'_strong_rate_clean']);
    print(fig,[stem,'.png'],'-dpng','-r300');
    print(fig,[stem,'.pdf'],'-dpdf','-painters');
    savefig(fig,[stem,'.fig']);
    fprintf('%s: %.6f %.6f %.6f %.6f %.6f\n',method,P(:,1));
end
fprintf('Figures saved in: %s\n',outdir);
end
