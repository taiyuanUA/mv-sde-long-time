MATLAB绘图更新
===============

1. 两个主图标题：
   The Strong Convergence Rate of PM
   The Strong Convergence Rate of SSBE

2. 不添加图下参数说明、脚注或额外副标题；关闭网格。
   保留坐标标记、六个误差点、五个维数、颜色、标记及斜率拟合。
   原始统计数据不做修改。主图PM仍使用alpha=1/8，未用补充实验数据替换。

运行方法A：独立绘图程序（推荐仅需重画图时使用）
-------------------------------------------------
将MATLAB当前工作目录切换到本文件所在目录，运行：
    plot_ips_rates_clean
或指定输入：
    plot_ips_rates_clean('data/summary.csv','figures_clean')

输出：figures_clean/PM_strong_rate_clean.* 和
      figures_clean/SSBE_strong_rate_clean.*
格式为PNG、矢量PDF和MATLAB FIG。无需重新运行随机模拟。

运行方法B：完整更新后的原程序
----------------------------
保持目录结构，运行：
    addpath('matlab');
    ips_strong_six('plot');

只修改了完整程序的绘图段和相关注释；simulate_all、数值求解器、
参考更新及测试函数与原文件完全一致。
此程序另有原先的alpha=1/4补充图，其标题仍保留supplement标记，
以免和主图混淆。

数据来源
--------
data/summary.csv逐字节复制自本会话已有的
/mnt/data/ips_rates_corrected/data/summary.csv。
该文件包含原先归档的统计量，本次未重新模拟，也未修改这些统计量。
本次仅进行了源代码修改、结构检查和数据一致性检查；
未在MATLAB解释器中执行更新的.m文件。
用于论文的图应由数值数据绘制，不应使用生成式图像编辑后的曲线。
