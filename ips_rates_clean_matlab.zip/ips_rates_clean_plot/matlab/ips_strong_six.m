function ips_strong_six(mode,outdir,R)
% IPS_STRONG_SIX  Six-stepsize strong-error experiment for the SAME-N IPS.
%
% Model: dX_i=(-2X_i-X_i.^3+0.5*mean_j X_j)dt+2dW_i.
% X0 has independent N(0,1) coordinates.  T=100, N=128.
% All approximations and references retain their OWN empirical mean.
% Main PM projection: min(1,h^(-1/8)/|x|)x (paper-admissible exponent).
% Supplement: exponent 1/4, explicitly labelled model-specific. This does
% NOT satisfy the generic alpha*(kappa-1)<1/3 condition for kappa=3.
% See the supplied model_specific_projection_lemma.tex before using it.
%
% ips_strong_six('plot')      redraw archived observed data (no simulation)
% Plot update: requested PM/SSBE titles; no footer; unchanged numeric data.
% ips_strong_six('test')      algebraic and solver checks
% ips_strong_six('simulate','my_results',32)   full simulation, all times
% ips_strong_six('audit','my_audit',8)         reference dt halved
%
% No Python or additional MATLAB toolbox is used. A fresh MATLAB run does
% not reproduce the C++ RNG bit for bit. It uses the same stochastic laws.
if nargin<1, mode='plot'; end
root=fileparts(fileparts(mfilename('fullpath')));
if nargin<2||isempty(outdir), outdir=fullfile(root,'data'); end
if nargin<3, R=32; if strcmpi(mode,'audit'), R=4; end; end
switch lower(mode)
    case 'plot'
        analyze_and_plot(outdir);
    case 'simulate'
        simulate_all(outdir,R,false);
        analyze_and_plot(outdir);
    case 'audit'
        simulate_all(outdir,R,true);
    case 'test'
        algebra_tests();
    otherwise
        error('Choose plot, simulate, audit, or test.');
end
end

function simulate_all(outdir,R,audit)
if ~exist(outdir,'dir'), mkdir(outdir); end
N=128; dims=[2,3,4,5,8]; H=2.^(-(8:13)); K=numel(H);
T=100; dt=2^-14; if audit, dt=dt/2; end
nsteps=round(T/dt); mult=round(H/dt);
assert(all(abs(mult*dt-H)<1e-14));
alpha=1/8; seed=902170;
obsTimes=unique([1,10,50,80:0.5:100]);
obsStep=round(obsTimes/dt);
methods={'SSBE','PM','PM_model_specific'};
allRecords=cell(R,1); allDiag=cell(R,1); allAudit=cell(R,1);
for rep=1:R
    rng(mod(seed+104729*rep,2^32-1),'twister');
    X0=randn(N,8); X=X0; Xa=X0;
    YS=cell(1,K); YP=cell(5,K); YQ=cell(5,K); acc=cell(1,K);
    hits=zeros(5,K,2); calls=zeros(5,K,2); maxnorm=zeros(5,K,2);
    maxit=0; maxres=0;
    for k=1:K
        YS{k}=X0; acc{k}=zeros(N,8);
        for q=1:5
            YP{q,k}=X0(:,1:dims(q)); YQ{q,k}=YP{q,k};
        end
    end
    rec=zeros(numel(obsTimes)*5*3*K,6); row=0; io=1;
    for step=1:nsteps
        w=sqrt(dt)*randn(N,8);
        J=0.5*dt*w+sqrt(dt^3/12)*randn(N,8);
        X=reference_step(X,w,J,dt);
        if audit
            if mod(step,2)==1
                wprev=w; Jprev=J;
            else
                wc=wprev+w; Jc=Jprev+dt*wprev+J;
                Xa=reference_step(Xa,wc,Jc,2*dt);
            end
        end
        for k=1:K
            acc{k}=acc{k}+w;
            if mod(step,mult(k))==0
                [Z,it,res]=ssbe_stage(YS{k},H(k));
                YS{k}=Z+2*acc{k};
                maxit=max(maxit,it); maxres=max(maxres,res);
                for q=1:5
                    d=dims(q);
                    [YP{q,k},nh,nm]=pm_step(YP{q,k},acc{k}(:,1:d),H(k),alpha);
                    hits(q,k,1)=hits(q,k,1)+nh;
                    calls(q,k,1)=calls(q,k,1)+N;
                    maxnorm(q,k,1)=max(maxnorm(q,k,1),nm);
                    [YQ{q,k},nh,nm]=pm_step(YQ{q,k},acc{k}(:,1:d),H(k),1/4);
                    hits(q,k,2)=hits(q,k,2)+nh;
                    calls(q,k,2)=calls(q,k,2)+N;
                    maxnorm(q,k,2)=max(maxnorm(q,k,2),nm);
                end
                acc{k}(:)=0;
            end
        end
        if io<=numel(obsStep) && step==obsStep(io)
            for q=1:5
                d=dims(q); ref=X(:,1:d);
                for k=1:K
                    mse=[mean(sum((YS{k}(:,1:d)-ref).^2,2)), ...
                         mean(sum((YP{q,k}-ref).^2,2)), ...
                         mean(sum((YQ{q,k}-ref).^2,2))];
                    for j=1:3
                        row=row+1; rec(row,:)=[rep-1,d,j,H(k),step*dt,mse(j)];
                    end
                end
            end
            io=io+1;
        end
    end
    O=array2table(rec(1:row,:), 'VariableNames',{'run','d','method_id','h','t','mse'});
    O.method=reshape(methods(O.method_id),[],1); O.method_id=[];
    O=O(:,{'run','d','method','h','t','mse'}); allRecords{rep}=O;
    dg=zeros(5*K*2,9); rr=0;
    for q=1:5
        for k=1:K
            for v=1:2
                rr=rr+1; dg(rr,:)=[rep-1,dims(q),v,H(k),hits(q,k,v),calls(q,k,v),maxnorm(q,k,v),maxit,maxres];
            end
        end
    end
    G=array2table(dg,'VariableNames',{'run','d','variant','h','projection_hits','projection_calls','maxnorm','max_newton','solver_residual'});
    nm={'PM','PM_model_specific'}; G.method=reshape(nm(G.variant),[],1);G.variant=[];
    allDiag{rep}=G;
    if audit
        rr=0; aa=zeros(5*3*K,7);
        refdiff=mean(sum((X-Xa).^2,2));
        for q=1:5
            d=dims(q); ref=Xa(:,1:d);
            for k=1:K
                vals=[mean(sum((YS{k}(:,1:d)-ref).^2,2)),mean(sum((YP{q,k}-ref).^2,2)),mean(sum((YQ{q,k}-ref).^2,2))];
                for j=1:3
                    rr=rr+1;aa(rr,:)=[rep-1,d,j,H(k),dt,vals(j),refdiff];
                end
            end
        end
        A=array2table(aa,'VariableNames',{'run','d','method_id','h','reference_dt','mse_to_coarse_reference','reference_difference_mse_d8'});
        A.method=reshape(methods(A.method_id),[],1); A.method_id=[]; allAudit{rep}=A;
    end
    % Save every completed full system so an interrupted MATLAB run is auditable.
    save(fullfile(outdir,sprintf('run_%04d.mat',rep)),'O','G','H','N','T','dt','alpha','seed');
    fprintf('Completed %d/%d independent IPSs.\n',rep,R);
end
O=vertcat(allRecords{:});G=vertcat(allDiag{:});
writetable(O,fullfile(outdir,'observations.csv'));
writetable(G,fullfile(outdir,'diagnostics.csv'));
if audit, A=vertcat(allAudit{:});writetable(A,fullfile(outdir,'audit.csv'));end
fid=fopen(fullfile(outdir,'config_matlab.txt'),'w');
fprintf(fid,'N=%d\nR=%d\nT=%g\nk0=8\nreference_dt=%.17g\nalpha=0.125\n',N,R,T,dt);fclose(fid);
end

function [z,it,res] = ssbe_stage(y,h)
% Fully coupled implicit stage. No empirical-mean suppression/freezing.
a=1+2*h; c=h/2; z=y; scale=1+max(abs(y),[],1);
for it=0:14
    F=(a+h*z.^2).*z-y-c*mean(z,1);
    res=max(max(abs(F),[],1)./scale);
    if res<=1e-12, return; end
    invD=1./(a+3*h*z.^2);g=invD.*F;
    denom=1-c*mean(invD,1);
    assert(all(denom>0),'Invalid Newton denominator.');
    shift=c*mean(g,1)./denom;
    z=z-g-invD.*shift;
end
error('Implicit stage failed the residual test.');
end

function [y,nh,mx] = pm_step(x,w,h,alpha)
% Each dimension d is simulated separately, because this projection is radial.
r=sqrt(sum(x.^2,2));mx=max(r);radius=h^(-alpha);
z=x; mask=r>radius;nh=sum(mask);
if nh>0, z(mask,:)=x(mask,:).*(radius./r(mask));end
b=-2*z-z.^3+0.5*mean(z,1);
y=z+h*b+2*w; % ALL Milstein corrections are identically zero in this model.
assert(all(isfinite(y(:))),'Nonfinite PM state.');
end

function y = reference_step(x,w,J,dt)
% Additive-noise Ito--Taylor reference, retaining the empirical drift.
% J = integral_t^(t+dt) (t+dt-u) dW_u.
b=-2*x-x.^3+0.5*mean(x,1); bp=-2-3*x.^2;
L0b=bp.*b+0.5*mean(b,1)-12*x;
y=x+dt*b+2*w+0.5*dt^2*L0b+2*bp.*J+mean(J,1);
if any(~isfinite(y(:)))||max(abs(y(:)))>1e6
    error('Reference integration failed; decrease the reference step.');
end
end

function analyze_and_plot(outdir)
hasRaw=exist(fullfile(outdir,'observations.csv'),'file')==2;
if hasRaw
    O=readtable(fullfile(outdir,'observations.csv'));
    S=O(abs(O.t-max(O.t))<1e-12,:);
else
    S=readtable(fullfile(outdir,'summary.csv'));
end
dims=[2,3,4,5,8]; H=sort(unique(S.h));
methods={'SSBE','PM','PM_model_specific'};
summary=cell(5*3*numel(H),5);sr=0;rat=cell(15,3);rr=0;
figdir=fullfile(fileparts(outdir),'figures_matlab');if ~exist(figdir,'dir'),mkdir(figdir);end
colors=[.55 .34 .29; .89 .47 .76; .45 .45 .45; .66 .65 .10; .10 .43 .78];
marks={'d','s','o','v','x'};
for a=1:3
    method=methods{a};E=zeros(5,numel(H));P=zeros(5,2);
    for q=1:5
        for k=1:numel(H)
            idx=strcmp(S.method,method)&S.d==dims(q)&abs(S.h-H(k))<1e-14;
            vals=S.mse(idx);assert(~isempty(vals));
            if hasRaw
                E(q,k)=sqrt(mean(vals));
            else
                assert(sum(idx)==1);E(q,k)=S.rms(idx);
            end
            sr=sr+1;summary(sr,:)={method,dims(q),H(k),mean(vals),E(q,k)};
        end
        P(q,:)=polyfit(log(H(:)),log(E(q,:).'),1);
        rr=rr+1;rat(rr,:)={method,dims(q),P(q,1)};
    end
    fig=figure('Color','w','Position',[80,80,1000,700]);
    ax=axes('Parent',fig,'Position',[0.14,0.14,0.83,0.76]);
    hold(ax,'on');box(ax,'on');
    set(ax,'XScale','log','YScale','log','FontName','Arial', ...
        'FontSize',13,'LineWidth',1,'TickDir','in', ...
        'XMinorTick','on','YMinorTick','on');
    hd=logspace(log10(min(H)),log10(max(H)),240);
    hr=gobjects(6,1);lg=cell(6,1);
    ref=1.6*max(E(:,end))/max(H)*hd;
    hr(1)=plot(ax,hd,ref,'--','Color',[0,.60,.15],'LineWidth',1.7);lg{1}='Reference slope 1';
    for q=1:5
        hr(q+1)=plot(ax,hd,exp(polyval(P(q,:),log(hd))),'-','Color',colors(q,:),'LineWidth',1.4);
        face=colors(q,:);if strcmp(marks{q},'x'),face='none';end
        plot(ax,H,E(q,:),marks{q},'LineStyle','none', ...
            'Color',colors(q,:),'MarkerFaceColor',face, ...
            'MarkerSize',7,'LineWidth',1.2,'HandleVisibility','off');
        set(hr(q+1),'HandleVisibility','off');
        hr(q+1)=plot(ax,NaN,NaN,'-','Color',colors(q,:), ...
            'LineWidth',1.4,'Marker',marks{q}, ...
            'MarkerFaceColor',face,'MarkerSize',7);
        lg{q+1}=sprintf('d=%d, slope=%.3f',dims(q),P(q,1));
    end
    xlabel(ax,'Step size $h$','Interpreter','latex','FontSize',16);
    ylabel(ax,'$\widehat{e}_{h,d}(T)$','Interpreter','latex','FontSize',18);
    if a==1
        ttl='The Strong Convergence Rate of SSBE';
    elseif a==2
        ttl='The Strong Convergence Rate of PM';
    else
        % Keep the supplementary alpha=1/4 experiment clearly identified.
        ttl='PM: model-specific alpha=1/4 (supplement)';
    end
    title(ax,ttl,'Interpreter','none','FontSize',18,'FontWeight','normal');
    legend(ax,hr,lg,'Interpreter','none', ...
        'Location','northwest','FontSize',11,'Box','on');
    grid(ax,'off');xlim(ax,[min(H)/1.35,max(H)*1.18]);
    % No figure footer or additional parameter annotation.
    set(fig,'PaperUnits','inches','PaperPosition',[0,0,10,7], ...
        'PaperSize',[10,7]);
    print(fig,fullfile(figdir,[method,'_six_h.png']),'-dpng','-r300');
    print(fig,fullfile(figdir,[method,'_six_h.pdf']),'-dpdf','-painters');
    savefig(fig,fullfile(figdir,[method,'_six_h.fig']));
end
A=cell2table(summary(1:sr,:),'VariableNames',{'method','d','h','mse','rmse'});
B=cell2table(rat(1:rr,:),'VariableNames',{'method','d','slope'});
writetable(A,fullfile(outdir,'matlab_summary.csv'));
writetable(B,fullfile(outdir,'matlab_rates.csv'));
disp(B);
end

function algebra_tests()
rng(83,'twister'); Y=randn(19,8); h=1/256;
[Z,~,res]=ssbe_stage(Y,h);assert(res<1e-12);
rr=(1+2*h)*Z+h*Z.^3-.5*h*mean(Z,1)-Y;assert(max(abs(rr(:)))<1e-10);
perm=randperm(19);Zp=ssbe_stage(Y(perm,:),h);er=Zp-Z(perm,:);assert(max(abs(er(:)))<1e-10);
w=sqrt(h)*randn(size(Y));Q=pm_step(Y,w,h,1/8);Qp=pm_step(Y(perm,:),w(perm,:),h,1/8);
er=Qp-Q(perm,:);assert(max(abs(er(:)))<1e-12);
% A radial projection is NOT consistent with taking dimension prefixes.
y=[2 2 2 2 2 2 2 2];r=h^(-1/8);z8=y*min(1,r/norm(y));z2=y(1:2)*min(1,r/norm(y(1:2)));
assert(norm(z2-z8(1:2))>0);
% The exact IPS drift is nonzero at its random empirical mean.
y=randn(23,4);b=-2*y-y.^3+.5*mean(y,1);eps=1e-6;
u=randn(size(y));bfun=@(a)-2*a-a.^3+.5*mean(a,1);
diff=(bfun(y+eps*u)-bfun(y-eps*u))/(2*eps);
formula=(-2-3*y.^2).*u+.5*mean(u,1);
er=diff-formula;assert(max(abs(er(:)))<1e-7);
fprintf('Residual, equivariance, projection-dimension and drift derivative tests passed.\n');
end
