from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
ROOT=Path(__file__).resolve().parents[1]
s=pd.read_csv(ROOT/'data/summary.csv');rates=pd.read_csv(ROOT/'data/rates.csv')
out=ROOT/'figures';out.mkdir(exist_ok=True)
for method,order in [('SSBE',0.5),('PM',1.0)]:
    a=s[(s.method==method)&(s.window=='terminal')].sort_values('h')
    assert len(a)==6
    h=a.h.to_numpy();err=a.rmse.to_numpy();p=np.polyfit(np.log(h),np.log(err),1)
    hd=np.geomspace(h.min(),h.max(),240);fit=np.exp(np.polyval(p,np.log(hd)))
    ref=1.6*np.exp(np.mean(np.log(err)-order*np.log(h)))*hd**order
    fig=plt.figure(figsize=(8.5,5.8));ax=fig.add_subplot(111)
    ax.set_xscale('log');ax.set_yscale('log')
    ax.plot(hd,fit,color='#245caf',lw=1.6)
    ax.plot(h,err,ls='none',marker='*',color='#245caf',ms=10,markeredgewidth=.7)
    ax.plot(hd,ref,'--',color='#189039',lw=1.9)
    handles=[Line2D([],[],color='#245caf',lw=1.6,marker='*',ms=9),Line2D([],[],color='#189039',lw=1.9,ls='--')]
    ax.legend(handles,[f'{method}, slope={p[0]:.3f}',f'Reference slope {order:g}'],loc='upper left',fontsize=12,frameon=True,fancybox=False,framealpha=1,edgecolor='.7')
    ax.set_xlabel(r'$h$',fontsize=18);ax.set_ylabel(r'$\widehat e_h(100)$',fontsize=18)
    ax.set_title(f'The Strong Convergence Rate of {method}',fontsize=17,pad=14,fontweight='normal')
    ax.tick_params(which='both',direction='in',labelsize=12);ax.grid(False)
    ax.set_xlim(h.min()/1.2,h.max()*1.2)
    fig.tight_layout(pad=1.3)
    fig.savefig(out/f'E3_{method}_strong.png',dpi=300)
    fig.savefig(out/f'E3_{method}_strong.pdf')
    plt.show()
    plt.close(fig)
print('Plotted all six observed same-N IPS errors per method. Only the reference slopes are prescribed.')
