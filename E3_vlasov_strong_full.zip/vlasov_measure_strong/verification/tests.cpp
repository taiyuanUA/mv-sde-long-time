#define main production_entry
#include "vlasov_experiment.cpp"
#undef main
int main(){try{
 std::mt19937_64 rng(19873);std::normal_distribution<double> z(0,1);int N=5,K=20;
 V x(K),y(K),dw(K);for(int k=0;k<K;k++){x[k]=z(rng);y[k]=z(rng);dw[k]=z(rng)*std::sqrt(1.0/1024);}
 double h=std::ldexp(1.,-10);Coef c(K),cp(K),cm(K);coeff(x,c);
 double maxfd=0;double eps=1e-6;
 for(int j=0;j<K;j++){
  V a=x,b=x;a[j]+=eps;b[j]-=eps;coeff(a,cp);coeff(b,cm);
  double dm=2.0/K*c.p[j]*c.pp[j];
  for(int l=0;l<K;l++){
   double deriv=(l==j?x[l]/std::sqrt(1+x[l]*x[l]):0)+0.25*dm;
   maxfd=std::max(maxfd,std::abs((cp.c[l]-cm.c[l])/(2*eps)-deriv));
   double db=(l==j?(-24-84*x[l]*x[l]+c.m*c.pp[l]):0)+c.p[l]*dm;
   maxfd=std::max(maxfd,std::abs((cp.b[l]-cm.b[l])/(2*eps)-db));
  }
 }
 if(maxfd>2e-6)throw std::runtime_error("derivative test");
 // Ordered integrals: contraction agrees with a full matrix.
 PM s(x,h);V W(K,0),I(K*K,0);int Q=32;double dt=h/Q;
 for(int n=0;n<Q;n++){
  for(double&a:dw)a=z(rng)*std::sqrt(dt);
  for(int j=0;j<K;j++)for(int l=0;l<K;l++)I[j*K+l]+=W[j]*dw[l]+0.5*(dw[j]*dw[l]-(j==l?dt:0));
  s.add(dw);for(int k=0;k<K;k++)W[k]+=dw[k];
 }
 double denseerr=0,diagerr=0,symerr=0;
 for(int l=0;l<K;l++){
  double u=0;for(int j=0;j<K;j++)u+=s.c.aa[j]*I[j*K+l];
  denseerr=std::max(denseerr,std::abs(u-s.j[l]+0.5*h*s.c.aa[l]));
  diagerr=std::max(diagerr,std::abs(I[l*K+l]-0.5*(W[l]*W[l]-h)));
  for(int j=0;j<K;j++)symerr=std::max(symerr,std::abs(I[j*K+l]+I[l*K+j]-(W[j]*W[l]-(j==l?h:0))));
 }
 if(denseerr>1e-13 || diagerr>1e-13 || symerr>1e-13)throw std::runtime_error("integral identity test");
 StageWork sw(K);Diag dg;V xp=x;
 ssbe(xp,dw,h,sw,dg);if(dg.residual>1e-12)throw std::runtime_error("Newton residual");
 // Analytic conditional one-step contraction check (not a simulation fit).
 double worst=-1;
 for(int test=0;test<500;test++){
  V xx(K),yy(K);for(int k=0;k<K;k++){xx[k]=2*z(rng);yy[k]=2*z(rng);}double before=0;for(int k=0;k<K;k++)before+=(xx[k]-yy[k])*(xx[k]-yy[k])/N;
  PM a(xx,h),b(yy,h);double det=0,gv=0,mv=0;
  for(int l=0;l<K;l++){
   double f=(a.x[l]+h*a.c.b[l])-(b.x[l]+h*b.c.b[l]);det+=f*f/N;
   double gd=a.c.c[l]-b.c.c[l];gv+=h*gd*gd/N;
   for(int j=0;j<K;j++){double ad=a.c.aa[j]-b.c.aa[j]+(l==j?a.c.k[l]-b.c.k[l]:0);mv+=0.5*h*h*ad*ad/N;}
  }
  worst=std::max(worst,(det+gv+mv)/before);
  if(det+gv+mv>(1-38*h)*before+1e-10)throw std::runtime_error("conditional contraction test");
 }
 std::cout<<std::setprecision(17)<<"{\"max_derivative_fd_error\":"<<maxfd<<",\"dense_area_contraction_error\":"<<denseerr<<",\"diagonal_integral_error\":"<<diagerr<<",\"shuffle_identity_error\":"<<symerr<<",\"Newton_residual\":"<<dg.residual<<",\"max_tested_conditional_contraction_ratio\":"<<worst<<",\"bound\":"<<1-38*h<<",\"status\":\"passed\"}"<<std::endl;
 return 0;
 }catch(std::exception&e){std::cerr<<e.what()<<std::endl;return 2;}}
