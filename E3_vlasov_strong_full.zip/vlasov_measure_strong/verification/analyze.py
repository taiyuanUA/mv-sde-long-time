from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'data'; A=ROOT/'audit'

def main_data():
    cfg=json.loads((D/'configuration.json').read_text())
    fs=sorted(D.glob('system_*.csv'),key=lambda p:int(p.stem.split('_')[1]))
    ids=[int(p.stem.split('_')[1]) for p in fs]
    complete=[r for r in ids if (D/f'diagnostic_{r}.csv').exists()]
    if len(complete)!=cfg['R']:
        raise RuntimeError(f"Only {len(complete)}/{cfg['R']} complete systems")
    raw=pd.concat([pd.read_csv(D/f'system_{r}.csv') for r in complete],ignore_index=True)
    raw.to_csv(D/'observations.csv',index=False)
    h=np.sort(raw.h.unique())[::-1];sy=np.sort(raw.system.unique())
    terminal=raw[raw.time==100]
    expected=cfg['R']*12
    assert len(terminal)==expected and raw.mse.ge(0).all() and np.isfinite(raw.mse).all()
    assert set(terminal.h)==set(2.**(-np.arange(16,22)))
    rng=np.random.default_rng(3031);B=5000;boot=rng.integers(0,len(sy),(B,len(sy)))
    rows=[];rates=[];adj=[];check=[]
    x=np.log(h);xc=x-x.mean()
    for method in ['SSBE','PM']:
        for window in ['terminal','late']:
            u=terminal if window=='terminal' else raw[(raw.time>=99)&(raw.time<=100)]
            E=u[u.method==method].groupby(['system','h']).mse.mean().unstack().reindex(index=sy,columns=h).to_numpy()
            assert np.isfinite(E).all() and np.all(E>0)
            err=np.sqrt(E.mean(axis=0)); fit=np.polyfit(x,np.log(err),1)
            bs=np.sqrt(E[boot].mean(axis=1));sl=np.log(bs)@xc/(xc@xc)
            lo,hi=np.quantile(sl,[.025,.975]);R2=1-np.sum((np.log(err)-np.polyval(fit,x))**2)/np.sum((np.log(err)-np.log(err).mean())**2)
            rates.append(dict(method=method,window=window,slope=fit[0],ci_low=lo,ci_high=hi,R_squared=R2,bootstrap_replicates=B))
            for j,hh in enumerate(h):
                loe,hie=np.quantile(bs[:,j],[.025,.975])
                rows.append(dict(method=method,window=window,h=hh,mse=E[:,j].mean(),rmse=err[j],ci_low=loe,ci_high=hie))
                if j<5:adj.append(dict(method=method,window=window,fine_h=h[j+1],adjacent_order=np.log(err[j]/err[j+1])/np.log(2)))
        for t in sorted(raw.time.unique()):
            if t<=98:continue
            e=np.sqrt(raw[(raw.time==t)&(raw.method==method)].groupby('h').mse.mean().reindex(h).to_numpy())
            check.append(dict(method=method,time=t,slope=np.polyfit(x,np.log(e),1)[0]))
    pd.DataFrame(rows).to_csv(D/'summary.csv',index=False)
    pd.DataFrame(rates).to_csv(D/'rates.csv',index=False)
    pd.DataFrame(adj).to_csv(D/'adjacent_orders.csv',index=False)
    pd.DataFrame(check).to_csv(D/'checkpoint_rates.csv',index=False)
    dg=pd.concat([pd.read_csv(D/f'diagnostic_{r}.csv') for r in sy])
    dg.to_csv(D/'diagnostics.csv',index=False)
    proj=terminal[terminal.method=='PM'].groupby('h').projection_hits.sum().reset_index()
    proj['total_tail_particle_updates']=cfg['R']*cfg['N']*(100-cfg['restart_time'])/proj.h
    proj['hit_fraction']=proj.projection_hits/proj.total_tail_particle_updates
    proj.to_csv(D/'projection_summary.csv',index=False)
    print(pd.DataFrame(rates).to_string(index=False));print('Diagnostics:\n',dg.describe().to_string());print('Empirical m: ',terminal.statistic_reference.describe().to_dict())

def audit_data():
    fs=sorted(A.glob('audit_*.csv'))
    if not fs: return
    u=pd.concat([pd.read_csv(p) for p in fs],ignore_index=True)
    assert (u.time.max()==100) and np.isfinite(u.mse_original).all()
    rows=[];rs=[]
    for window in ['terminal','late']:
        v=u[u.time==100] if window=='terminal' else u[u.time>=99]
        for (method,h),w in v.groupby(['method','h']):
            vals=w.groupby('system')[['mse_original','mse_ref_fine','mse_both_fine','area_difference_mse','reference_difference_mse']].mean().mean()
            e=np.sqrt(vals)
            rows.append(dict(window=window,method=method,h=h,rmse_original=e.mse_original,rmse_ref_fine=e.mse_ref_fine,rmse_both_fine=e.mse_both_fine,ref_change_percent=100*(e.mse_ref_fine/e.mse_original-1),area_change_percent=100*(e.mse_both_fine/e.mse_ref_fine-1),area_difference_rms=e.area_difference_mse,reference_difference_rms=e.reference_difference_mse,R=w.system.nunique()))
    out=pd.DataFrame(rows);out.to_csv(A/'reference_area_check.csv',index=False)
    for (win,m),w in out.groupby(['window','method']):
        for which in ['rmse_original','rmse_ref_fine','rmse_both_fine']:
            rs.append(dict(window=win,method=m,variant=which,slope=np.polyfit(np.log(w.h),np.log(w[which]),1)[0]))
    pd.DataFrame(rs).to_csv(A/'audit_rates.csv',index=False)
    print(out.to_string(index=False)); print(pd.DataFrame(rs).to_string(index=False))

if __name__=='__main__':
    if len(sys.argv)==1 or sys.argv[1]=='main':main_data()
    if len(sys.argv)==1 or sys.argv[1]=='audit':audit_data()
