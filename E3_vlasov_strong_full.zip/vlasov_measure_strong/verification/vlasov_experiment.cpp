#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
#include <omp.h>
using V=std::vector<double>;
constexpr int D=4,L=6;
struct Coef {
 V p,pp,c,b,aa,k; double m;
 Coef(int n):p(n),pp(n),c(n),b(n),aa(n),k(n){}
};
static inline void phival(double x,double &p,double &pp){
 double p1=std::sqrt(1+(x+1)*(x+1)),p2=std::sqrt(1+(x-1)*(x-1));
 p=2*x/(p1+p2); pp=0.5*((x+1)/p1-(x-1)/p2);
}
void coeff(const V& x,Coef& co){
 const int K=x.size(); double sum=0;
 for(int k=0;k<K;k++){phival(x[k],co.p[k],co.pp[k]);sum+=co.p[k]*co.p[k];}
 co.m=sum/K;
 for(int k=0;k<K;k++){
  double g=std::sqrt(1+x[k]*x[k]); co.c[k]=g+co.m*0.25;
  co.b[k]=-24*x[k]-28*x[k]*x[k]*x[k]+co.m*co.p[k];
  co.k[k]=x[k]/g*co.c[k];
  // a=(1/(4N))*partial_r chi*c = phi*phi'*c/(8N) = .../(2K)
  co.aa[k]=co.p[k]*co.pp[k]*co.c[k]/(2*K);
 }
}
struct Diag{double residual=0,maxnorm=0,maxmean=0;long long hits=0,latehits=0,solves=0;int iter=0;};
struct StageWork {V z,p,pp,F,inv;StageWork(int n):z(n),p(n),pp(n),F(n),inv(n){}};
void ssbe(V& x,const V& w,double h,StageWork &sw,Diag &dg){
 int K=x.size();sw.z=x; double scale=1;for(double a:x)scale=std::max(scale,1+std::abs(a));
 double m=0,err=0;
 for(int it=0;it<=12;it++){
  m=0;for(int k=0;k<K;k++){phival(sw.z[k],sw.p[k],sw.pp[k]);m+=sw.p[k]*sw.p[k];}m/=K;
  err=0;
  for(int k=0;k<K;k++){double z=sw.z[k];sw.F[k]=(1+24*h)*z+28*h*z*z*z-h*m*sw.p[k]-x[k];err=std::max(err,std::abs(sw.F[k])/scale);}
  if(err<=1e-12){dg.residual=std::max(dg.residual,err);dg.iter=std::max(dg.iter,it);break;}
  if(it==12 || !std::isfinite(err))throw std::runtime_error("Newton did not converge");
  double vFinv=0,vUinv=0;
  for(int k=0;k<K;k++){
   sw.inv[k]=1/(1+24*h+84*h*sw.z[k]*sw.z[k]-h*m*sw.pp[k]);
   double v=2.0/K*sw.p[k]*sw.pp[k];
   vFinv+=v*sw.inv[k]*sw.F[k];vUinv+=v*sw.inv[k]*sw.p[k];
  }
  double beta=h*vFinv/(1-h*vUinv);
  for(int k=0;k<K;k++)sw.z[k]-=sw.inv[k]*(sw.F[k]+sw.p[k]*beta);
 }
 for(int k=0;k<K;k++)x[k]=sw.z[k]+(std::sqrt(1+sw.z[k]*sw.z[k])+m*0.25)*w[k];
 dg.solves++;
}
struct PM { V x,w,j;Coef c; double h,rad,az;long long hits=0,latehits=0;PM(const V& x0,double h0):x(x0),w(x0.size()),j(x0.size()),c(x0.size()),h(h0),rad(std::pow(h0,-0.125)),az(0){prepare(0);}
 void prepare(double t){for(int i=0;i<(int)x.size();i+=4){double n2=0;for(int s=0;s<4;s++)n2+=x[i+s]*x[i+s];if(n2>rad*rad){double f=rad/std::sqrt(n2);for(int s=0;s<4;s++)x[i+s]*=f;hits++;if(t>=80)latehits++;}}coeff(x,c);std::fill(w.begin(),w.end(),0);std::fill(j.begin(),j.end(),0);az=0;}
 void add(const V& dw){double adot=0;for(int k=0;k<(int)x.size();k++)adot+=c.aa[k]*dw[k];double mid=az+0.5*adot;for(int k=0;k<(int)x.size();k++){j[k]+=mid*dw[k];w[k]+=dw[k];}az+=adot;}
 void finish(double t){for(int k=0;k<(int)x.size();k++)x[k]+=h*c.b[k]+c.c[k]*w[k]+0.5*c.k[k]*(w[k]*w[k]-h)+j[k]-0.5*h*c.aa[k]; if(t<1e100){} }
};
void pmref(V& x,const V& dw,double h,Coef& c){coeff(x,c);double aw=0;for(int k=0;k<(int)x.size();k++)aw+=c.aa[k]*dw[k];for(int k=0;k<(int)x.size();k++)x[k]+=h*c.b[k]+c.c[k]*dw[k]+0.5*c.k[k]*(dw[k]*dw[k]-h)+0.5*(aw*dw[k]-h*c.aa[k]);}
// Main production experiment uses a rigorously controlled contractive restart.
// X0~N(0,I4); SSBE at hw=2^-8 until t0=98; each tested fixed-h method then
// evolves on [98,100]. See restart_bound.tex: the L2 discrepancy from the
// corresponding method run at fixed h on [0,100] is at most 4*exp(-38).
V warm(int N,std::mt19937_64& gen,std::normal_distribution<double>& normal,Diag& dg,double t0){
 int K=4*N;V y(K),dw(K);for(double&a:y)a=normal(gen);
 double hw=std::ldexp(1.0,-8);StageWork sw(K);
 for(long long n=0;n<llround(t0/hw);n++){for(double&a:dw)a=std::sqrt(hw)*normal(gen);ssbe(y,dw,hw,sw,dg);}
 return y;
}
void project_ref(V& x,double radius,long long& hits){
 for(int i=0;i<(int)x.size();i+=4){double n2=0;for(int s=0;s<4;s++)n2+=x[i+s]*x[i+s];if(n2>radius*radius){double f=radius/std::sqrt(n2);for(int s=0;s<4;s++)x[i+s]*=f;hits++;}}
}
void do_main(int N,int R,int er,const std::string&out,int seed0,bool restart){
 constexpr int E0=16; const double T=100,t0=restart?98.0:0.0;
 int K=4*N;double dt=std::ldexp(1.0,-er),rad=std::pow(dt,-0.125);long long ns=llround((T-t0)/dt);
 std::filesystem::create_directories(out);std::array<double,L> h;std::array<long long,L> ratio;
 for(int l=0;l<L;l++){h[l]=std::ldexp(1.0,-E0-l);ratio[l]=llround(h[l]/dt);if(ratio[l]<1)throw std::runtime_error("ref grid too coarse");}
 auto start=std::chrono::steady_clock::now();omp_set_num_threads(4);
 {std::ofstream f(out+"/configuration.json");f<<"{\"model\":\"E3 Vlasov kernel law-dependent diffusion\",\"N\":"<<N<<",\"R\":"<<R<<",\"d\":4,\"T\":100,\"restart_time\":"<<t0<<",\"warm_h\":0.00390625,\"first_h_exponent\":16,\"last_h_exponent\":21,\"reference_exponent\":"<<er<<",\"area_mesh_exponent\":"<<er<<",\"seed\":"<<seed0<<"}";}
 #pragma omp parallel for schedule(dynamic)
 for(int r=0;r<R;r++){
  std::mt19937_64 gen(seed0+104729ULL*r);std::normal_distribution<double> norm(0,1);Diag dg;
  V x0=warm(N,gen,norm,dg,t0);V dw(K),ref=x0;
  std::array<V,L> ys,ws;std::vector<PM> yp;for(int l=0;l<L;l++){ys[l]=x0;ws[l].assign(K,0);yp.emplace_back(x0,h[l]);}
  StageWork sw(K);Coef cr(K);long long refhits=0;double maxdiff=0,maxmean=0,maxref=0;
  std::ofstream file(out+"/system_"+std::to_string(r)+".csv");
  file<<"system,time,method,h,mse,statistic_reference,projection_hits\n"<<std::setprecision(17);
  auto record=[&](double t){coeff(ref,cr);maxmean=std::max(maxmean,cr.m);for(int l=0;l<L;l++){double e1=0,e2=0;for(int k=0;k<K;k++){e1+=(ys[l][k]-ref[k])*(ys[l][k]-ref[k]);e2+=(yp[l].x[k]-ref[k])*(yp[l].x[k]-ref[k]);}file<<r<<","<<t<<",SSBE,"<<h[l]<<","<<e1/N<<","<<cr.m<<",0\n";file<<r<<","<<t<<",PM,"<<h[l]<<","<<e2/N<<","<<cr.m<<","<<yp[l].hits<<"\n";}};
  // store endpoints at 98,98.25,...,100, always before next projection
  record(t0);
  const long long saveEvery=llround(0.25/dt);
  for(long long n=1;n<=ns;n++){
   for(double&a:dw)a=std::sqrt(dt)*norm(gen);
   project_ref(ref,rad,refhits);pmref(ref,dw,dt,cr);
   for(int l=0;l<L;l++){
    yp[l].add(dw);for(int k=0;k<K;k++)ws[l][k]+=dw[k];
    if(n%ratio[l]==0){ssbe(ys[l],ws[l],h[l],sw,dg);std::fill(ws[l].begin(),ws[l].end(),0);yp[l].finish(t0+n*dt);}
   }
   if(n%saveEvery==0 || n==ns){record(t0+n*dt);for(int i=0;i<K;i+=4){double ss=0;for(int j=0;j<4;j++)ss+=ref[i+j]*ref[i+j];maxref=std::max(maxref,std::sqrt(ss));}}
   if(n<ns)for(int l=0;l<L;l++)if(n%ratio[l]==0)yp[l].prepare(t0+n*dt);
  }
  file.close();
  {std::ofstream f(out+"/diagnostic_"+std::to_string(r)+".csv");f<<"system,newton_residual,newton_max_updates,reference_projection_hits,max_ref_norm_at_saved_times,max_empirical_statistic\n"<<std::setprecision(17)<<r<<","<<dg.residual<<","<<dg.iter<<","<<refhits<<","<<maxref<<","<<maxmean<<"\n";}
  #pragma omp critical
  std::cout<<"system "<<r<<" finished, wall "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<" sec"<<std::endl;
 }
 std::cout<<"PRODUCTION COMPLETE: wall "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<" sec"<<std::endl;
}
void do_audit(int N,int R,int er,const std::string&out,int seed0){
 int K=4*N;double dt=std::ldexp(1.0,-er),fine=dt/2,t0=98,T=100;
 long long ns=llround((T-t0)/dt);std::array<double,L> h;std::array<long long,L> ratio;
 for(int l=0;l<L;l++){h[l]=std::ldexp(1.0,-16-l);ratio[l]=llround(h[l]/dt);}
 std::filesystem::create_directories(out);omp_set_num_threads(4);auto start=std::chrono::steady_clock::now();
 #pragma omp parallel for schedule(dynamic)
 for(int r=0;r<R;r++){
  std::mt19937_64 gen(seed0+104729ULL*r);std::normal_distribution<double> norm(0,1);Diag dg;
  V x0=warm(N,gen,norm,dg,t0),ref0=x0,ref1=x0,dw1(K),dw2(K),dw(K);
  std::array<V,L> ys,ws;std::vector<PM> yp0,yp1;
  for(int l=0;l<L;l++){ys[l]=x0;ws[l].assign(K,0);yp0.emplace_back(x0,h[l]);yp1.emplace_back(x0,h[l]);}
  StageWork sw(K);Coef cr0(K),cr1(K);long long hit0=0,hit1=0;
  std::ofstream file(out+"/audit_"+std::to_string(r)+".csv");file<<"system,time,method,h,mse_original,mse_ref_fine,mse_both_fine,area_difference_mse,reference_difference_mse\n"<<std::setprecision(17);
  for(long long n=1;n<=ns;n++){
   for(int k=0;k<K;k++){dw1[k]=std::sqrt(fine)*norm(gen);dw2[k]=std::sqrt(fine)*norm(gen);dw[k]=dw1[k]+dw2[k];}
   project_ref(ref0,std::pow(dt,-0.125),hit0);pmref(ref0,dw,dt,cr0);
   project_ref(ref1,std::pow(fine,-0.125),hit1);pmref(ref1,dw1,fine,cr1);project_ref(ref1,std::pow(fine,-0.125),hit1);pmref(ref1,dw2,fine,cr1);
   for(int l=0;l<L;l++){
    yp0[l].add(dw);yp1[l].add(dw1);yp1[l].add(dw2);for(int k=0;k<K;k++)ws[l][k]+=dw[k];
    if(n%ratio[l]==0){ssbe(ys[l],ws[l],h[l],sw,dg);std::fill(ws[l].begin(),ws[l].end(),0);yp0[l].finish(t0+n*dt);yp1[l].finish(t0+n*dt);}
   }
   if(n%llround(0.25/dt)==0 || n==ns){double rr=0;for(int k=0;k<K;k++)rr+=(ref0[k]-ref1[k])*(ref0[k]-ref1[k]);rr/=N;
    for(int l=0;l<L;l++)for(int method=0;method<2;method++){double e0=0,e1=0,e2=0,ar=0;const V&x=method==0?ys[l]:yp0[l].x;const V&xf=method==0?ys[l]:yp1[l].x;
     for(int k=0;k<K;k++){e0+=(x[k]-ref0[k])*(x[k]-ref0[k]);e1+=(x[k]-ref1[k])*(x[k]-ref1[k]);e2+=(xf[k]-ref1[k])*(xf[k]-ref1[k]);ar+=(xf[k]-x[k])*(xf[k]-x[k]);}
     file<<r<<","<<t0+n*dt<<","<<(method==0?"SSBE":"PM")<<","<<h[l]<<","<<e0/N<<","<<e1/N<<","<<e2/N<<","<<ar/N<<","<<rr<<"\n";}
   }
   if(n<ns)for(int l=0;l<L;l++)if(n%ratio[l]==0){yp0[l].prepare(t0+n*dt);yp1[l].prepare(t0+n*dt);}
  }
  file.close();
  #pragma omp critical
  std::cout<<"audit system "<<r<<" complete, wall "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<std::endl;
 }
 std::cout<<"AUDIT COMPLETE, wall "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<std::endl;
}
int main(int argc,char**argv){try{
 std::string mode=argc>1?argv[1]:"main";int N=argc>2?std::stoi(argv[2]):32,R=argc>3?std::stoi(argv[3]):16,er=argc>4?std::stoi(argv[4]):24;
 std::string out=argc>5?argv[5]:"/mnt/data/vlasov_measure_strong/data";int seed=argc>6?std::stoi(argv[6]):41087;
 if(mode=="audit")do_audit(N,R,er,out,seed);else do_main(N,R,er,out,seed,mode!="full");
 return 0;
 }catch(std::exception&e){std::cerr<<"FAILED: "<<e.what()<<std::endl;return 2;}}
