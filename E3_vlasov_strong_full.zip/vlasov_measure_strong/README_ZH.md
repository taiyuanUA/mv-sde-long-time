# 第三个四维 Vlasov 模型：含测度扩散的 SSBE/PM 强误差实验

## 0. 已做了什么，未声称什么

本实验的目标是**同一个 N=32 的 IPS**与时间离散数值解之间的均方根误差，不是传播混沌误差，也没有用零均值极限过程代替 IPS。维数固定为 d=m=4，终点 T=100，主实验 R=16 个独立完整系统。六个步长为 2^(-16),...,2^(-21)。所有系数均与题目一致。

为使极细网格计算可执行，实际模拟采用**有明确误差证书的共同预热/重启**：从 N(0,I4) 独立初值，用 SSBE、步长 2^(-8) 模拟至 t=98，再将每个被测步长和细参考都初始化在这个共同状态，并各自推进至 100。这**不等于声称每个极细网格都在 [0,100] 上直接执行了全部时间步**。在本模型中，同步数值流的平方距离每步收缩不超过 1-38h，且二阶矩不超过4。附件 `latex/restart_bound.tex` 证明：每条重启数值轨道与相同算法在[0,100]以固定步长从原初值完整推进的虚拟轨道之间，归一化 L2 差不超过 4 exp(-38) < 1.26e-16；两个过程的总体 RMS 差值因此最多改变 8 exp(-38) < 2.52e-16。这个证明仅涉及重启误差，不涉及时间离散、面积离散、统计或舍入误差。

实际执行的是 `verification/vlasov_experiment.cpp`；纯 MATLAB 实现为 `matlab/vlasov_measure_strong.m`。当前环境没有 MATLAB/Octave，未在 MATLAB 解释器中执行 .m 文件。MATLAB 和 C++ 随机数发生器不同，独立重跑不应逐位一致。`simulate_full` 给出没有重启的完整固定步长版本，但本轮没有执行该极高成本版本。

## 1. 模型

```
phi(u) = [sqrt(1+(u+1)^2)-sqrt(1+(u-1)^2)]/2
Phi(x) = (phi(x1),...,phi(x4))
chi(y) = (1/4) sum_s phi(y_s)^2
m(mu) = integral chi(y) mu(dy)
b(x,mu) = -24x-28x^[3]+m(mu) Phi(x)
c_s(x,mu) = sqrt(1+x_s^2)+m(mu)/4
S(x,mu) = diag(c1,...,c4)
```

Vlasov 核为 `tilde b(x,y)=Phi(x)chi(y)`。它有界且全局 Lipschitz。扩散含非零测度项；该项不是均值，因此不能因为分布中心对称就删掉它。

数值中用等价且更稳定的 `phi(u)=2u/(sqrt(1+(u+1)^2)+sqrt(1+(u-1)^2))` 计算。系数本身没有改变。

## 2. 假设1--5的参数

采用诱导矩阵/多线性算子范数，可取

- q0=80, kappa=3, L=10584, Lsigma=2;
- K1=44, K2=83/2，故 K1-K2=5/2>0;
- a1=4, a2=0, C0=912;
- C_M=168;
- alpha=1/8，alpha(kappa-1)=1/4<1/3;
- p_SSBE=14，p_PM=68，均不超过q0。

基本界为 |phi|<=1, 0<=phi'<=1, |phi''|<=1/2, |grad chi|<=1, ||Hess chi||<=3/4。
由此 |m(mu)-m(nu)|<=W2(mu,nu), |Phi|<=2，且交互漂移差被 |x-y|+2W2(mu,nu) 控制。
令 B=sum_s(x_s-y_s)^2(x_s^2+x_sy_s+y_s^2)。则

`||S(x,mu)-S(y,nu)||^2 <= (2/3)B + (1/2)W2(mu,nu)^2`

与三次耗散 -56B 结合，给出 -44|x-y|²+(83/2)W2²。
Lyapunov 估计使用

`||S||² <=2|x|²+17/2`

和 `116u²-56u⁴ <=841/14`，得到 -4|x|²+12765/14 <= -4|x|²+912。

导数为

```
Dx b = -24I -84diag(x_s²)+m diag(phi'(x_s))
Dxx b[u,v] = ((-168x_s+m phi''(x_s))u_sv_s)_s
DL b(x,mu)(v) = Phi(x) grad chi(v)^T
DxDL b[u] = DPhi(x)u grad chi(v)^T
DvDL b[vdir] = Phi(x)(Hess chi(v)vdir)^T
D^(L,2)b = 0
Dx sigma_s = g'(x_s)e_s e_s^T
Dxx sigma_s[u,v] = g''(x_s)u_sv_s e_s
DL sigma_s(x,mu)(v) = (1/4)e_s grad chi(v)^T
DvDL sigma_s[vdir] = (1/4)e_s(Hess chi(v)vdir)^T
```

其它空间--测度混合扩散导数和二阶纯测度导数为零。漂移导数之和<=168(1+|x|²)，扩散导数之和<3；所需一阶扩散导数的 Lipschitz 界立即成立。

本实验未计算正文通用高阶 Lyapunov 常数给出的 h_mom 数值，因而**不声称六个h已经通过那个通用高阶充分门槛的数值检查**。本文件证明的是用于加速的独立模型专用二阶矩与收缩界；它不能替代所有高阶 H3 条件的独立验证。

## 3. 两种实际更新

每个系统保留 N 个四维粒子，m_N = (4N)^(-1)sum_(i,s)phi(x_is)^2。

SSBE：解整个耦合隐式方程

`(1+24h)z_i+28h z_i^[3]-h m_N(z)Phi(z_i)=y_i`

然后 `y_i^+ = z_i + diag(sqrt(1+z_is²)+m_N(z)/4) dw_i`。
Jacobian 是对角矩阵减去秩一矩阵；Newton 的每次线性系统通过 Sherman--Morrison 精确求解，不冻结旧时刻 m_N。残差阈值1e-12；若未收敛程序报错，不静默接受。

PM：先将每个四维粒子径向投影到半径 h^(-1/8) 的球中，令 z_i 为投影值，所有漂移/扩散/导数均在投影经验测度处计算。完整修正为

```
y_is^+ = z_is+h b_is + c_is dw_is
         + (1/2)g'(z_is)c_is(dw_is²-h)
         + sum_(j,r) a_jr I_(j,r;i,s),
a_jr = phi(z_jr)phi'(z_jr)c_jr/(8N).
```

这里末项是**非零 Lions 导数修正**，包含所有粒子编号和方向，不删掉 i!=j 项。
总体扩散向量场通常不交换；仅仅在状态上写成对角阵，不意味着完整 IPS 的 Milstein 修正可由增量乘积全部精确表达。

## 4. 迭代积分如何实际计算

参考时间网格和初始面积网格均为 delta=2^(-24)。所有粗步增量由对应 fine increments 累加。对一个粗步 h，设 delta 增量为 w_l，B_l 为粗步内前 l 个增量之和。使用有明确条件期望意义的近似

`Ihat_ab = sum_l { B_l,a w_l,b + (w_l,a w_l,b -delta 1_(a=b))/2 }`。

- 它等于 exact ordered Ito integral 关于已观测 Brownian 子网格增量的条件期望；
- 对角项精确等于 ((Delta W_a)^2-h)/2；
- 保留子区间之间所有有序面积贡献；
- 子网格以下的 Brownian bridge 面积仍是未解析误差，**不能称其为零或声称模拟了精确 Levy 面积**；
- 本实验不是 Wiktorsson Fourier 算法，也不把该算法的收敛阶冒充本实现的结论。

因为测度修正系数 a_jr 与输出粒子编号无关，可以直接累加 `sum_a a_a Ihat_ab`，无需存储 (4N)^2 张量。令 A_l=a dot B_l，则该加权修正等于

`J_b = sum_l (A_l+(a dot w_l)/2)w_l,b - (h/2)a_b`。

逐步计算 `A_l` 和 `J_b` 的成本为O(N)。这只是完整修正的代数重排，不是忽略跨粒子项。已用小系统中的显式稠密 Ito 矩阵进行核对，误差见tests.json。

对冻结a，未解析面积误差满足精确的条件均方公式

`E_n |sum_a a_a(I_ab-Ihat_ab)|² = h delta (|a|²-a_b²)/4`。

因此有限子网格仍带有独立的面积近似误差。若要研究h趋于0时某个完全离散实现的渐近阶，必须相应缩小面积网格（例如使delta=O(h²)）或采用更有效的面积模拟器；本次只研究所列六个h，并另外进行配对面积精度检查。

参考本身是同一个 N 的更细 PM，包含同样的完整测度修正。在单个参考单元中使用上述条件期望公式，因此它也不是未知精确 IPS 路径。

## 5. 统计与独立性

主图用T100终端指标

`e_hat_h = sqrt[ (1/(RN)) sum_(r,i) |Y_h^(i,r)(100)-X_ref^(i,r)(100)|² ]`。

先对粒子和独立系统的平方误差平均，再开平方。每个方法用全部六个h进行自由对数回归。没有固定拟合斜率，没有用拟合数值替换散点。

对数回归的不确定性通过5000次系统级bootstrap评估；同一次重采样保留该系统的所有步长和方法数据。保存时刻为98:0.25:100，另报告99:0.25:100上的先平均MSE再开方的辅助窗口统计；主图仍然是T100终端指标。

## 6. 两种数值精度影响分开检查

四个另外的独立系统使用原网格delta及其一半。粗步仍是原六个h。

1. 保持粗方法结果不变，改变 reference delta -> delta/2，测量reference影响；
2. 保持新细参考不变，改变粗PM面积网格delta -> delta/2，测量面积影响；
3. SSBE没有面积积分，因此第二项对SSBE为零。

同一审计中的 w_coarse = w1+w2，原面积积分按w_coarse累加，新面积积分按w1,w2分别累加；二者同源，不独立重抽。既报告RMS误差数值的相对变化，也报告两条面积分辨率轨道之间的L2差。两种统计不能混同。结果在audit/reference_area_check.csv和audit/audit_rates.csv。

## 7. 运行

MATLAB默认只绘图：

```matlab
addpath('matlab');
vlasov_measure_strong('plot');
vlasov_measure_strong('configuration');
vlasov_measure_strong('test');
% 重新模拟（含上面严格披露的共同预热加速）：
vlasov_measure_strong('simulate','my_results',16);
% 分开检查参考和面积网格：
vlasov_measure_strong('audit','my_audit',4);
% 完全不使用预热重启的全区间固定h版本，计算量极大：
vlasov_measure_strong('simulate_full','my_full_results',16);
```

C++数值核可通过如下命令复现归档模拟；`.m`文件不依赖这些命令。

```bash
g++ -O3 -march=native -fno-math-errno -fopenmp -std=c++17 \
  verification/vlasov_experiment.cpp -o experiment
./experiment main 32 16 24 data 41087
./experiment audit 32 4 24 audit 95171
```

使用标准IEEE双精度；没有开启不安全fast-math。图像均从CSV统计生成，无生成式绘图。纯MATLAB数值内核未经本环境MATLAB解释器运行；源码包含自检命令。输出CSV格式与归档相同。

## 8. 数据来源与理论来源

当前模型、参数验证、重启误差界、低秩积分缩并和本次实测值由本实验给出。用户提供的一步法文章采用同步细网格参考和RMS误差，作为实验组织方式的参考；不将它们的数值表搬到本模型。

Bao, Reisinger, Ren and Stockinger (2021), DOI 10.1098/rspa.2020.0258：粒子Milstein方法中Lions导数项的重要性及非交换噪声。
Wiktorsson (2001), DOI 10.1214/aoap/1015345301：联合迭代Itô积分模拟的背景；本代码没有调用该文的Fourier算法。

预期阶是SSBE半阶、PM一阶；具体实测阶必须由生成的rates.csv报告，不预先写入。
