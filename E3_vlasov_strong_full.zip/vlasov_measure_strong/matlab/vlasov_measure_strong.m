function out = vlasov_measure_strong(action,outdir,R)
% Four-dimensional Vlasov MV-SDE: same-N IPS strong error experiment.
% b_i = -24*x_i-28*x_i.^3 + mN*phi(x_i)
% c_i = sqrt(1+x_i.^2)+mN/4, mN=mean(phi(X(:)).^2).
%
% plot            redraw the archived observations (no new simulation)
% configuration   display all parameters
% test            algebraic, derivative, coupling and Newton tests
% simulate        certified restart: SSBE to 98, tested methods on [98,100]
% simulate_full   each tested resolution on [0,100] (VERY expensive)
% analyze         recompute tables and fits from system_*.csv
% audit           halve BOTH reference and Brownian area meshes, separating
%                 their effects in the output; default 4 independent IPSs
%
% The actual archived experiment was executed by the included C++ kernel.
% This pure MATLAB implementation does not call Python or an external engine.
% The MATLAB and C++ random generators need not give bitwise identical data.
if nargin<1, action='plot'; end
root=fileparts(fileparts(mfilename('fullpath')));
if nargin<2 || isempty(outdir)
    if strcmpi(action,'audit'), outdir=fullfile(root,'audit');
    else, outdir=fullfile(root,'data'); end
end
cfg=configuration();
if nargin>=3 && ~isempty(R), cfg.R=R;
elseif strcmpi(action,'audit'), cfg.R=4; end
out=[];
switch lower(action)
    case 'configuration'
        disp(cfg); out=cfg;
    case 'test'
        out=run_tests();
    case {'simulate','simulate_full'}
        if strcmpi(action,'simulate_full'), cfg.restart_time=0; end
        simulate(cfg,outdir); out=analyze(outdir);
        plot_saved(outdir,fullfile(outdir,'figures'));
    case 'audit'
        simulate_audit(cfg,outdir); out=analyze_audit(outdir);
    case 'analyze'
        out=analyze(outdir);
    case 'plot'
        if ~isfile(fullfile(outdir,'summary.csv')), analyze(outdir); end
        plot_saved(outdir,fullfile(root,'figures'));
    otherwise
        error('Unknown action: %s',action);
end
end

function cfg=configuration()
cfg.d=4; cfg.N=32; cfg.R=16; cfg.T=100;
cfg.h=2.^(-(16:21)); cfg.href=2^-24; cfg.area_mesh=cfg.href;
cfg.alpha=1/8; cfg.hwarm=2^-8; cfg.restart_time=98;
cfg.seed=41087; cfg.tol=1e-12; cfg.save_dt=1/4;
cfg.restart_L2_bound_per_process=4*exp(-38);
end

function [p,pp,ppp]=phi_all(x)
a=sqrt(1+(x+1).^2); b=sqrt(1+(x-1).^2);
% Algebraically identical to (a-b)/2, with less cancellation.
p=2*x./(a+b);
pp=0.5*((x+1)./a-(x-1)./b);
if nargout>=3, ppp=0.5*(a.^(-3)-b.^(-3)); end
end

function [drift,c,a,k,m]=coeff(x)
assert(size(x,2)==4,'This model is fixed in dimension four.');
N=size(x,1); [p,pp]=phi_all(x);
m=mean(p(:).^2); g=sqrt(1+x.^2);
c=g+m/4;
drift=-24*x-28*x.^3+m*p;
k=(x./g).*c;
% a_{j,r}=(1/(4N))*partial_r chi(x_j)*c_{j,r}.
a=p.*pp.*c/(8*N);
end

function [z,nit,res]=implicit_stage(y,h)
N=size(y,1); z=y; scale=1+max(abs(y(:)));
for nit=0:12
    [p,pp]=phi_all(z); m=mean(p(:).^2);
    F=(1+24*h)*z+28*h*z.^3-h*m*p-y;
    res=max(abs(F(:)))/scale;
    if ~isfinite(res), error('Non-finite Newton residual.'); end
    if res<=1e-12, return; end
    if nit==12, error('Newton iteration did not converge.'); end
    invD=1./(1+24*h+84*h*z.^2-h*m*pp);
    v=p.*pp/(2*N); % gradient of empirical m with respect to ALL coordinates
    denom=1-h*sum(v(:).*invD(:).*p(:));
    if denom<=0, error('Nonpositive rank-one Newton denominator.'); end
    q=h*sum(v(:).*invD(:).*F(:))/denom;
    z=z-invD.*(F+p*q);
end
end

function [x,nit,res]=ssbe_step(x,dw,h)
[z,nit,res]=implicit_stage(x,h);
[p,~]=phi_all(z); m=mean(p(:).^2);
x=z+(sqrt(1+z.^2)+m/4).*dw;
end

function [z,hits]=project_rows(y,h)
norms=sqrt(sum(y.^2,2)); radius=h^(-1/8);
z=y; mask=norms>radius; hits=sum(mask);
if any(mask), z(mask,:)=y(mask,:).*(radius./norms(mask)); end
end

function st=prepare_pm(y,h,hits)
if nargin<3, hits=0; end
[st.x,nnew]=project_rows(y,h); st.h=h; st.hits=hits+nnew;
[st.b,st.c,st.a,st.k,st.m]=coeff(st.x);
st.w=zeros(size(y)); st.J=zeros(size(y)); st.az=0;
end

function st=add_area_increment(st,dw)
% Conditional expectation of the ordered Ito integrals on the observed
% Brownian subgrid. This is NOT the commutative product shortcut over h.
z=sum(st.a(:).*dw(:));
st.J=st.J+(st.az+z/2).*dw;
st.w=st.w+dw; st.az=st.az+z;
end

function y=finish_pm(st)
y=st.x+st.h*st.b+st.c.*st.w ...
    +0.5*st.k.*(st.w.^2-st.h) ...
    +st.J-0.5*st.h*st.a;
end

function [y,hits]=reference_step(y,dw,dt)
% Full projected Milstein on the reference time grid; its within-cell
% ordered integrals are conditional expectations given dw. The subcell
% Levy areas are unresolved, not asserted to be zero in the exact SDE.
[y,hits]=project_rows(y,dt);
[b,c,a,k]=coeff(y); aw=sum(a(:).*dw(:));
y=y+dt*b+c.*dw+0.5*k.*(dw.^2-dt) ...
    +0.5*(aw.*dw-dt*a);
end

function y=warm_start(cfg)
y=randn(cfg.N,4);
steps=round(cfg.restart_time/cfg.hwarm);
for n=1:steps
    y=ssbe_step(y,sqrt(cfg.hwarm)*randn(cfg.N,4),cfg.hwarm);
end
end

function simulate(cfg,outdir)
if ~exist(outdir,'dir'), mkdir(outdir); end
save(fullfile(outdir,'configuration.mat'),'cfg');
fid=fopen(fullfile(outdir,'configuration.txt'),'w');
fprintf(fid,'N=%d R=%d T=%.16g t_restart=%.16g href=%.16g\n', ...
    cfg.N,cfg.R,cfg.T,cfg.restart_time,cfg.href); fclose(fid);
H=cfg.h; dt=cfg.href; ns=round((cfg.T-cfg.restart_time)/dt);
ratio=round(H/dt); assert(all(abs(ratio*dt-H)<1e-14));
saveEvery=round(cfg.save_dt/dt);
fprintf('Actual fine interval [%g,%g], %d reference steps per system.\n', ...
    cfg.restart_time,cfg.T,ns);
for r=0:cfg.R-1
    rng(cfg.seed+104729*r,'twister');
    x0=warm_start(cfg); ref=x0; ys=cell(1,6); ws=ys; pm=ys; py=ys;
    for l=1:6
        ys{l}=x0; ws{l}=zeros(size(x0)); pm{l}=prepare_pm(x0,H(l)); py{l}=pm{l}.x;
    end
    path=fullfile(outdir,sprintf('system_%d.csv',r));
    fid=fopen(path,'w'); if fid<0, error('Cannot open %s',path); end
    clean=onCleanup(@()fclose(fid));
    fprintf(fid,'system,time,method,h,mse,statistic_reference,projection_hits\n');
    write_observation(fid,r,cfg.restart_time,H,ys,py,pm,ref);
    maxres=0; maxit=0; refhits=0;
    for n=1:ns
        dw=sqrt(dt)*randn(cfg.N,4);
        [ref,hit]=reference_step(ref,dw,dt); refhits=refhits+hit;
        for l=1:6
            pm{l}=add_area_increment(pm{l},dw); ws{l}=ws{l}+dw;
            if mod(n,ratio(l))==0
                [ys{l},it,res]=ssbe_step(ys{l},ws{l},H(l));
                maxit=max(maxit,it); maxres=max(maxres,res);
                ws{l}(:)=0; py{l}=finish_pm(pm{l});
            end
        end
        if mod(n,saveEvery)==0 || n==ns
            write_observation(fid,r,cfg.restart_time+n*dt,H,ys,py,pm,ref);
        end
        if n<ns
            for l=1:6
                if mod(n,ratio(l))==0
                    pm{l}=prepare_pm(py{l},H(l),pm{l}.hits);
                end
            end
        end
    end
    clear clean;
    D=table(r,maxres,maxit,refhits,'VariableNames', ...
        {'system','newton_residual','newton_max_updates','reference_projection_hits'});
    writetable(D,fullfile(outdir,sprintf('diagnostic_%d.csv',r)));
    fprintf('System %d/%d saved.\n',r+1,cfg.R);
end
end

function write_observation(fid,r,t,H,ys,py,pm,ref)
[p,~]=phi_all(ref); m=mean(p(:).^2);
for l=1:6
    e=mean(sum((ys{l}-ref).^2,2));
    fprintf(fid,'%d,%.17g,SSBE,%.17g,%.17g,%.17g,0\n',r,t,H(l),e,m);
    e=mean(sum((py{l}-ref).^2,2));
    fprintf(fid,'%d,%.17g,PM,%.17g,%.17g,%.17g,%d\n',r,t,H(l),e,m,pm{l}.hits);
end
end

function simulate_audit(cfg,outdir)
if ~exist(outdir,'dir'), mkdir(outdir); end
H=cfg.h; dt=cfg.href; half=dt/2; ratio=round(H/dt);
ns=round((cfg.T-cfg.restart_time)/dt); saveEvery=round(cfg.save_dt/dt);
for r=0:cfg.R-1
    rng(95171+104729*r,'twister'); x0=warm_start(cfg);
    r0=x0; r1=x0; ys=cell(1,6); ws=ys; p0=ys; p1=ys; y0=ys; y1=ys;
    for l=1:6
        ys{l}=x0; ws{l}=zeros(size(x0));
        p0{l}=prepare_pm(x0,H(l)); p1{l}=prepare_pm(x0,H(l));
    end
    fid=fopen(fullfile(outdir,sprintf('audit_%d.csv',r)),'w');
    clean=onCleanup(@()fclose(fid));
    fprintf(fid,['system,time,method,h,mse_original,mse_ref_fine,' ...
        'mse_both_fine,area_difference_mse,reference_difference_mse\n']);
    for n=1:ns
        w1=sqrt(half)*randn(cfg.N,4); w2=sqrt(half)*randn(cfg.N,4); w=w1+w2;
        r0=reference_step(r0,w,dt);
        r1=reference_step(r1,w1,half); r1=reference_step(r1,w2,half);
        for l=1:6
            p0{l}=add_area_increment(p0{l},w);
            p1{l}=add_area_increment(p1{l},w1); p1{l}=add_area_increment(p1{l},w2);
            ws{l}=ws{l}+w;
            if mod(n,ratio(l))==0
                ys{l}=ssbe_step(ys{l},ws{l},H(l)); ws{l}(:)=0;
                y0{l}=finish_pm(p0{l}); y1{l}=finish_pm(p1{l});
            end
        end
        if mod(n,saveEvery)==0 || n==ns
            rr=mean(sum((r0-r1).^2,2));
            for l=1:6
                for method=1:2
                    if method==1, x=ys{l}; xf=x; name='SSBE';
                    else, x=y0{l}; xf=y1{l}; name='PM'; end
                    e0=mean(sum((x-r0).^2,2)); e1=mean(sum((x-r1).^2,2));
                    e2=mean(sum((xf-r1).^2,2)); ar=mean(sum((x-xf).^2,2));
                    fprintf(fid,'%d,%.17g,%s,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g\n', ...
                        r,cfg.restart_time+n*dt,name,H(l),e0,e1,e2,ar,rr);
                end
            end
        end
        if n<ns
            for l=1:6
                if mod(n,ratio(l))==0
                    p0{l}=prepare_pm(y0{l},H(l),p0{l}.hits);
                    p1{l}=prepare_pm(y1{l},H(l),p1{l}.hits);
                end
            end
        end
    end
    clear clean;
    fprintf('Audit %d/%d complete.\n',r+1,cfg.R);
end
end

function A=read_set(outdir,pattern)
f=dir(fullfile(outdir,pattern)); if isempty(f), error('No raw files in %s',outdir); end
C=cell(numel(f),1);for j=1:numel(f), C{j}=readtable(fullfile(outdir,f(j).name)); end
A=vertcat(C{:}); A.method=string(A.method);
end

function summary=analyze(outdir)
A=read_set(outdir,'system_*.csv'); methods=["SSBE","PM"];
H=sort(unique(A.h),'descend'); systems=unique(A.system); nR=numel(systems); T=max(A.time);
method={}; hs=[]; mse=[]; rmse=[]; rateMethod={}; rateSlope=[]; lo=[]; hi=[];
adjMethod={}; adjH=[]; adjOrder=[];
rng(3031,'twister'); B=5000; boot=randi(nR,nR,B);
for m=1:2
    E=zeros(nR,6);
    for r=1:nR
        for l=1:6
            idx=A.system==systems(r) & A.time==T & A.method==methods(m) & A.h==H(l);
            assert(sum(idx)==1); E(r,l)=A.mse(idx);
        end
    end
    e=sqrt(mean(E,1)); p=polyfit(log(H),log(e(:)),1);
    bootE=zeros(B,6);
    for l=1:6, v=E(:,l); bootE(:,l)=sqrt(mean(reshape(v(boot),nR,B),1))'; end
    xx=log(H); xx=xx-mean(xx); bootSlope=log(bootE)*xx/(xx'*xx);
    interval=percentile(bootSlope,[0.025 0.975]);
    rateMethod{end+1,1}=char(methods(m)); rateSlope(end+1,1)=p(1);lo(end+1,1)=interval(1);hi(end+1,1)=interval(2);
    for l=1:6
        method{end+1,1}=char(methods(m));hs(end+1,1)=H(l);
        mse(end+1,1)=mean(E(:,l));rmse(end+1,1)=e(l);
        if l<6
            adjMethod{end+1,1}=char(methods(m));adjH(end+1,1)=H(l+1);
            adjOrder(end+1,1)=log(e(l)/e(l+1))/log(H(l)/H(l+1));
        end
    end
end
summary=table(method,hs,mse,rmse,'VariableNames',{'method','h','mse','rmse'});
rates=table(rateMethod,rateSlope,lo,hi,'VariableNames',{'method','slope','ci_low','ci_high'});
adj=table(adjMethod,adjH,adjOrder,'VariableNames',{'method','fine_h','adjacent_order'});
writetable(summary,fullfile(outdir,'summary.csv'));writetable(rates,fullfile(outdir,'rates.csv'));
writetable(adj,fullfile(outdir,'adjacent_orders.csv'));disp(rates);
end

function p=percentile(x,q)
x=sort(x(:));n=numel(x);idx=1+(n-1)*q; i=floor(idx);j=ceil(idx);
p=x(i)'.*(j-idx)+x(j)'.*(idx-i); eq=i==j;p(eq)=x(i(eq));
end

function S=analyze_audit(outdir)
A=read_set(outdir,'audit_*.csv');A=A(A.time==max(A.time),:);
methods=["SSBE","PM"];H=sort(unique(A.h),'descend');rows=cell(12,9);k=0;
for m=1:2
    for l=1:6
        U=A(A.method==methods(m)&A.h==H(l),:);
        x=sqrt(mean(U.mse_original));y=sqrt(mean(U.mse_ref_fine));z=sqrt(mean(U.mse_both_fine));
        k=k+1;rows(k,:)={char(methods(m)),H(l),x,y,z,100*(y/x-1),100*(z/y-1), ...
            sqrt(mean(U.area_difference_mse)),sqrt(mean(U.reference_difference_mse))};
    end
end
S=cell2table(rows,'VariableNames',{'method','h','rmse_original','rmse_ref_fine', ...
    'rmse_both_fine','ref_change_percent','area_change_percent','area_difference_rms','reference_difference_rms'});
writetable(S,fullfile(outdir,'reference_area_check.csv'));disp(S);
end

function plot_saved(outdir,figdir)
A=readtable(fullfile(outdir,'summary.csv'));A.method=string(A.method);
if ismember('window',A.Properties.VariableNames), A=A(string(A.window)=="terminal",:); end
if ~exist(figdir,'dir'),mkdir(figdir);end
for m=["SSBE","PM"]
    U=A(A.method==m,:);U=sortrows(U,'h');assert(height(U)==6,'Expected exactly six observed points.');h=U.h;e=U.rmse;
    p=polyfit(log(h),log(e),1);hd=logspace(log10(min(h)),log10(max(h)),240);
    fit=exp(polyval(p,log(hd)));
    if m=="SSBE",order=0.5;else,order=1;end
    cref=1.55*exp(mean(log(e)-order*log(h)));
    fig=figure('Color','w','Position',[100 100 960 680]);ax=axes('Parent',fig);hold(ax,'on');box(ax,'on');
    set(ax,'XScale','log','YScale','log','FontSize',14,'LineWidth',1,'TickDir','in');
    a=plot(ax,hd,fit,'-','Color',[0.12 0.36 0.70],'LineWidth',1.6);
    plot(ax,h,e,'*','Color',[0.12 0.36 0.70],'MarkerSize',9,'LineWidth',1.2,'HandleVisibility','off');
    b=plot(ax,hd,cref*hd.^order,'--','Color',[0 .60 .15],'LineWidth',1.8);
    title(ax,['The Strong Convergence Rate of ',char(m)],'FontWeight','normal','FontSize',19);
    xlabel(ax,'$h$','Interpreter','latex','FontSize',19);
    ylabel(ax,'$\widehat e_h(100)$','Interpreter','latex','FontSize',19);
    legend(ax,[a b],{sprintf('%s, slope=%.3f',m,p(1)),sprintf('Reference slope %g',order)},'Location','northwest','FontSize',13);
    grid(ax,'off');xlim(ax,[min(h)/1.2 max(h)*1.2]);
    set(fig,'PaperPositionMode','auto');name=fullfile(figdir,['E3_',char(m),'_strong']);
    print(fig,[name,'.png'],'-dpng','-r300');print(fig,[name,'.pdf'],'-dpdf','-bestfit');savefig(fig,[name,'.fig']);
end
end

function ok=run_tests()
rng(591,'twister');N=5;x=randn(N,4);dw=randn(N,4)*sqrt(2^-10);
% Nonzero measure derivative and finite-difference identity.
[b,c,a,k,m]=coeff(x);K=numel(x);z=x;eps0=1e-6;idx=7;z(idx)=z(idx)+eps0;
[b1,c1]=coeff(z);[p,pp]=phi_all(x);gradm=p.*pp/(2*N);
assert(max(abs((c1(:)-c(:))/eps0-((1:K)'==idx)*(x(idx)/sqrt(1+x(idx)^2))-gradm(idx)/4))<3e-6);
% Complete coupled Newton residual and row-permutation equivariance.
[hx,~,res]=implicit_stage(x,2^-10);assert(res<=1e-12);
perm=[3 5 1 4 2];xp=implicit_stage(x(perm,:),2^-10);
assert(max(abs(xp(:)-reshape(hx(perm,:),[],1)))<1e-11);
% Low-rank area accumulator equals contraction against a dense ordered-Ito matrix.
h=2^-9;q=16;dt=h/q;w=sqrt(dt)*randn(K,q);st=prepare_pm(x,h);aa=st.a(:);
W=zeros(K,1);II=zeros(K);for j=1:q
    u=w(:,j);II=II+W*u'+0.5*(u*u'-dt*eye(K));W=W+u;
    st=add_area_increment(st,reshape(u,N,4));
end
low=st.J(:)-h*aa/2;dense=II'*aa;
assert(max(abs(low-dense))<1e-14);
assert(max(abs(diag(II)-(W.^2-h)/2))<1e-14);
assert(max(max(abs(II+II'-(W*W'-h*eye(K)))))<1e-14);
% phi is odd, chi is even, and actual law correction coefficients are nonzero.
[pneg,~]=phi_all(-x);assert(max(abs(p(:)+pneg(:)))<1e-14);assert(norm(a(:))>0);
% Check PM update against its explicit dense formula.
out=finish_pm(st);[dr,cs,aas,ks]=coeff(st.x);
wmat=reshape(W,N,4);expected=st.x+h*dr+cs.*wmat+0.5*ks.*(wmat.^2-h)+reshape(II'*aas(:),N,4);
assert(max(abs(out(:)-expected(:)))<1e-13);
% Conditions on the projection exponent and moments.
assert((1/8)*(3-1)<1/3);assert(max(18,4+8/(1/8))==68);
assert(8*exp(-38)<3e-16);
ok=true;disp('All algebraic tests passed.');
end
