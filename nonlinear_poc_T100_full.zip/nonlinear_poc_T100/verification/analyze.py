from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.stats import t as tdist
ROOT=Path(__file__).resolve().parents[1]
raw=pd.read_csv(ROOT/'data/raw_errors.csv')
Ns=sorted(raw.N.unique());dims=[2,3,4,5,8];reps=sorted(raw.rep.unique());R=len(reps)
rng=np.random.default_rng(947821);rows=[];rates=[]
for d in dims:
    col=f'mse_d{d}'
    means=[];late_means=[];gridmax=[];samples=[];lates=[]
    for N in Ns:
        part=raw[raw.N==N]
        terminal=part[part.t==100].sort_values('rep')[col].to_numpy()
        late=part[part.t>=80].groupby('rep')[col].mean().to_numpy()
        m=terminal.mean();se=terminal.std(ddof=1)/np.sqrt(R)
        maxgrid=part.groupby('t')[col].mean().max()
        rows.append([d,int(N),m,se,max(0,m-tdist.ppf(.975,R-1)*se),m+tdist.ppf(.975,R-1)*se,late.mean(),late.std(ddof=1)/np.sqrt(R),maxgrid])
        means.append(m);late_means.append(late.mean());gridmax.append(maxgrid);samples.append(terminal);lates.append(late)
    x=np.log(Ns);x0=x-x.mean();B=5000
    bm=np.column_stack([s[rng.integers(0,R,size=(B,R))].mean(axis=1) for s in samples])
    bslopes=(np.log(bm)@x0)/(x0@x0)
    bl=np.column_stack([s[rng.integers(0,R,size=(B,R))].mean(axis=1) for s in lates])
    blslopes=(np.log(bl)@x0)/(x0@x0)
    p=np.polyfit(x,np.log(means),1);q=np.polyfit(x,np.log(late_means),1)
    rates.append([d,p[0],*np.quantile(bslopes,[.025,.975]),q[0],*np.quantile(blslopes,[.025,.975]),np.polyfit(x,np.log(gridmax),1)[0]])
summary=pd.DataFrame(rows,columns=['d','N','mse_T','se_T','ci_low','ci_high','mse_late','se_late','max_grid_mean'])
summary.to_csv(ROOT/'data/summary.csv',index=False)
rate=pd.DataFrame(rates,columns=['d','slope_T','ci_low_T','ci_high_T','slope_late','ci_low_late','ci_high_late','slope_max_grid'])
rate.to_csv(ROOT/'data/rates.csv',index=False)
print(rate.to_string(index=False));print('\nENDPOINT MSE');print(summary.pivot(index='N',columns='d',values='mse_T').to_string())
diag=pd.read_csv(ROOT/'data/solver_diagnostics.csv');print('\nDIAGNOSTICS',diag.iloc[:,2:].max().to_dict())
ref=ROOT/'data/raw_refinement.csv'
if ref.exists():
    r=pd.read_csv(ref);out=[]
    for d in dims:
        for which,ss in [('T100',r[r.t==100]),('late80_100',r[r.t>=80])]:
            rr=ss.groupby('rep')[[f'c_d{d}',f'f_d{d}',f'diff_d{d}']].mean()
            c,f,dd=rr.mean().to_numpy();ratio=c/f-1
            rng2=np.random.default_rng(72389+d);idx=rng2.integers(0,len(rr),size=(5000,len(rr)))
            bs=rr.to_numpy()[idx].mean(axis=1);ci=np.quantile(bs[:,0]/bs[:,1]-1,[.025,.975])
            out.append([d,which,c,f,100*ratio,100*ci[0],100*ci[1],np.sqrt(dd),np.sqrt(dd/f)])
    refsum=pd.DataFrame(out,columns=['d','window','coarse_mse','fine_mse','relative_percent','ci_low_percent','ci_high_percent','coupling_difference_rms','difference_relative_rms'])
    refsum.to_csv(ROOT/'data/refinement_summary.csv',index=False);print('\nREFINEMENT');print(refsum.to_string(index=False))
