from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'figures';OUT.mkdir(exist_ok=True)
DIMS=[2,3,4,5,8]
FIT={2:'#ff7f0e',3:'#2ca02c',4:'#ff3838',5:'#808080',8:'#ff7f0e'}
MARK={2:'#8c564b',3:'#e377c2',4:'#808080',5:'#bcbd22',8:'#1f77b4'}
SYMBOL={2:'D',3:'s',4:'o',5:'v',8:'x'}
GREEN='#00a61f'
def main():
    S=pd.read_csv(ROOT/'data/summary.csv')
    for key,ds,title in [('a',[2,3],r'(a) PoC rates for $d\in\{2,3\}$'),
                       ('b',[4],r'(b) PoC rates for $d=4$'),
                       ('c',[5,8],r'(c) PoC rates for $d\in\{5,8\}$')]:
        fig=plt.figure(figsize=(5.8,5.0));ax=fig.add_axes([.17,.15,.79,.75])
        legends=[];lo=np.inf;hi=0;anchor=0
        for d in ds:
            s=S[S.d==d].sort_values('N');n=s.N.to_numpy();e=s.mse_T.to_numpy()
            p=np.polyfit(np.log(n),np.log(e),1)
            dense=np.geomspace(n[0],n[-1],250);fit=np.exp(np.polyval(p,np.log(dense)))
            ax.loglog(dense,fit,color=FIT[d],linewidth=1.6)
            ax.loglog(n,e,linestyle='none',marker=SYMBOL[d],color=MARK[d],markersize=5.3,markeredgewidth=1.2)
            legends.append(Line2D([],[],color=FIT[d],lw=1.6,marker=SYMBOL[d],markersize=5.3,
                markerfacecolor=MARK[d],markeredgecolor=MARK[d],label=f'd={d}, slope={p[0]:.3f}'))
            anchor=max(anchor,float(np.exp(np.polyval(p,np.log(n[0])))))
            lo=min(lo,min(e.min(),fit.min()));hi=max(hi,e.max())
        reference=1.8*anchor*(dense/n[0])**(-1)
        ax.loglog(dense,reference,'--',color=GREEN,lw=2.0)
        hi=max(hi,reference.max());ax.set_xscale('log');ax.set_yscale('log')
        ax.set_xlim(32,3200);ax.set_ylim(lo*.65,hi*1.35)
        ax.set_xlabel('Number of Particles',fontsize=13)
        ax.set_ylabel('PoC-Error',fontsize=13)
        ax.set_title(title,fontsize=17,pad=10)
        ax.tick_params(which='both',direction='in',top=True,right=True,labelsize=11)
        ax.legend(handles=[Line2D([],[],color=GREEN,ls='--',lw=2,label='Order 1')]+legends,
                loc='lower left',fontsize=10.5,framealpha=1)
        fig.savefig(OUT/f'panel_{key}.png',dpi=220)
        fig.savefig(OUT/f'panel_{key}.pdf')
        plt.close(fig)
    raw=pd.read_csv(ROOT/'data/raw_errors.csv')
    fig=plt.figure(figsize=(8.0,4.5));ax=fig.add_axes([.12,.16,.85,.77])
    for N in [40,160,640,2560]:
        s=raw[raw.N==N].groupby('t').mse_d4.mean();s=s[s.index>0]
        ax.semilogy(s.index,s.to_numpy(),lw=1,label=f'N={N}')
    ax.set_xlabel('Time',fontsize=12);ax.set_ylabel('PoC-Error (mean-square)',fontsize=12)
    ax.set_xlim(0,100);ax.legend(loc='upper right',fontsize=10)
    ax.tick_params(which='both',direction='in',top=True,right=True)
    fig.savefig(OUT/'long_time_d4.png',dpi=200)
    fig.savefig(OUT/'long_time_d4.pdf');plt.close(fig)
    print('Saved data-based figures to',OUT)
if __name__=='__main__': main()
