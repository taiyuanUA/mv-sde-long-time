#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
#include <omp.h>

// Fully nonlinear, coordinatewise cubic mean-field SDE:
// b_l(x,mu)=-2*x_l-x_l^3+0.5*m_l(mu), sigma=2*I.
// Particle and mean-zero reference use the SAME initial sample and noise.
// No equilibrium initialization, no centering of particle samples, no rate input.
struct Diagnostics { int iters=0; double residual=0; double maxstate=0; };
void drift(std::vector<double>& z, const std::vector<double>& y,
           int N, double h, bool interacting, Diagnostics& diag) {
    const double a=1.0+2.0*h, c=interacting ? 0.5*h : 0.0;
    z=y;
    double scale=1.0;
    for(double v:y) scale=std::max(scale,1.0+std::abs(v));
    std::vector<double> v(N),g(N);
    for(int it=0;it<12;it++) {
        double mz=0; if(interacting) {for(double x:z)mz+=x; mz/=N;}
        double residual=0,mg=0,mv=0;
        for(int i=0;i<N;i++) {
            const double zz=z[i]*z[i];
            const double F=(a+h*zz)*z[i]-c*mz-y[i];
            residual=std::max(residual,std::abs(F));
            v[i]=1.0/(a+3.0*h*zz); g[i]=v[i]*F;
            mg+=g[i]; mv+=v[i];
        }
        if(residual<=1e-12*scale) {
            diag.iters=std::max(diag.iters,it);
            diag.residual=std::max(diag.residual,residual/scale);
            return;
        }
        const double correction=c*(mg/N)/(1.0-c*(mv/N));
        for(int i=0;i<N;i++)z[i]-=g[i]+v[i]*correction;
    }
    throw std::runtime_error("Implicit cubic solve did not converge.");
}
struct Job {int N,rep;};
struct Result {std::vector<std::array<double,5>> mse; Diagnostics dg;};
int main(int argc,char**argv) {
    std::string out="/mnt/data/nonlinear_poc_T100/data";
    int R=32,oneN=0; double T=100,h=1.0/64.0,save=0.25;
    for(int i=1;i<argc;i++) {
        std::string s=argv[i];
        if(s=="--out")out=argv[++i]; else if(s=="--R")R=std::stoi(argv[++i]);
        else if(s=="--N")oneN=std::stoi(argv[++i]);
        else if(s=="--T")T=std::stod(argv[++i]);
        else if(s=="--h")h=std::stod(argv[++i]);
    }
    std::vector<int> Ns=oneN?std::vector<int>{oneN}:std::vector<int>{40,80,160,320,640,1280,2560};
    int steps=std::lround(T/h),stride=std::lround(save/h),nt=steps/stride+1;
    if(stride<1 || std::abs(steps*h-T)>1e-10) throw std::runtime_error("Invalid grid");
    std::vector<Job>jobs;for(int N:Ns)for(int r=0;r<R;r++)jobs.push_back({N,r});
    std::vector<Result>results(jobs.size());
    auto start=std::chrono::steady_clock::now();
    #pragma omp parallel for schedule(dynamic)
    for(int job=0;job<(int)jobs.size();job++) {
        int N=jobs[job].N,rep=jobs[job].rep;
        std::mt19937_64 rng(20260913ULL+1000003ULL*N+7919ULL*(rep+1));
        std::normal_distribution<double>norm(0.,1.);
        std::array<std::vector<double>,8>Y,X;
        for(int l=0;l<8;l++) {Y[l].resize(N);X[l].resize(N);for(int i=0;i<N;i++)X[l][i]=Y[l][i]=norm(rng);}
        std::vector<double>z,zx;
        Result&ans=results[job];ans.mse.resize(nt);ans.mse[0].fill(0.);
        const double noise=2*std::sqrt(h);int ksave=1;
        for(int k=1;k<=steps;k++) {
            for(int l=0;l<8;l++) {
                drift(z,Y[l],N,h,true,ans.dg);drift(zx,X[l],N,h,false,ans.dg);
                for(int i=0;i<N;i++){
                    double dw=noise*norm(rng);
                    Y[l][i]=z[i]+dw;X[l][i]=zx[i]+dw;
                    ans.dg.maxstate=std::max(ans.dg.maxstate,std::max(std::abs(Y[l][i]),std::abs(X[l][i])));
                }
            }
            if(k%stride==0) {
                double cumulative=0;int pos=0;
                for(int l=0;l<8;l++) {
                    double s=0;for(int i=0;i<N;i++){double e=Y[l][i]-X[l][i];s+=e*e;}
                    cumulative+=s/N;
                    if(l+1==2||l+1==3||l+1==4||l+1==5||l+1==8) ans.mse[ksave][pos++]=cumulative;
                }
                ksave++;
            }
        }
        #pragma omp critical
        {if(rep==R-1)std::cerr<<"Completed N="<<N<<" final replicate; elapsed "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<" s\n";}
    }
    std::ofstream raw(out+"/raw_errors.csv");raw<<"N,rep,t,mse_d2,mse_d3,mse_d4,mse_d5,mse_d8\n"<<std::setprecision(17);
    std::ofstream diag(out+"/solver_diagnostics.csv");diag<<"N,rep,max_newton_updates,max_scaled_residual,max_state\n"<<std::setprecision(17);
    for(int j=0;j<(int)jobs.size();j++){
        auto b=jobs[j];auto&r=results[j];
        diag<<b.N<<","<<b.rep+1<<","<<r.dg.iters<<","<<r.dg.residual<<","<<r.dg.maxstate<<"\n";
        for(int k=0;k<nt;k++){raw<<b.N<<","<<b.rep+1<<","<<k*stride*h;for(double v:r.mse[k])raw<<","<<v;raw<<"\n";}
    }
    std::ofstream meta(out+"/run_metadata.txt");
    meta<<"Model: b_l=-2x_l-x_l^3+0.5mean_l; sigma=2I\nInitial: iid N(0,I_d), no empirical centering\nT="<<T<<"\nh="<<std::setprecision(17)<<h<<"\nR="<<R<<"\nsave_dt="<<save<<"\nDimensions=2,3,4,5,8 (first coordinates of same 8D simulation)\nseed=20260913+1000003*N+7919*(rep+1), C++ mt19937_64\nMethod=fully coupled SSBE and mean-zero reference SSBE\nRuntime_seconds="<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<"\n";
    std::cerr<<"DONE "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<" seconds\n";
    return 0;
}
