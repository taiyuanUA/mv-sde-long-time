#define main simulation_main
#include "run_nonlinear.cpp"
#undef main
int main(){
    for(double h: {1./64.,1./128.,1.}){
        for(bool interacting: {false,true}){
            std::vector<double>y={-8,-2,-.2,0,.7,3,9},z;
            Diagnostics d;drift(z,y,(int)y.size(),h,interacting,d);
            double mean=0;for(double x:z)mean+=x;mean/=z.size();
            double res=0;for(int i=0;i<(int)y.size();i++)res=std::max(res,std::abs((1+2*h)*z[i]+h*z[i]*z[i]*z[i]-(interacting?.5*h*mean:0)-y[i]));
            if(res>1e-9)throw std::runtime_error("residual test failed");
            std::reverse(y.begin(),y.end());std::vector<double>rev;drift(rev,y,(int)y.size(),h,interacting,d);std::reverse(rev.begin(),rev.end());
            for(int i=0;i<(int)z.size();i++)if(std::abs(z[i]-rev[i])>1e-10)throw std::runtime_error("permutation test failed");
        }
    }
    std::cout<<"All implicit residual and permutation tests passed.\n";
}
