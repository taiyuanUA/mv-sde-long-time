#define main simulation_main
#include "run_nonlinear.cpp"
#undef main
int main(int argc,char**argv){
    std::string out="/mnt/data/nonlinear_poc_T100/data";
    int R=32,N=2560; double T=100,h=1./64.;
    for(int i=1;i<argc;i++){std::string s=argv[i];if(s=="--out")out=argv[++i];else if(s=="--R")R=std::stoi(argv[++i]);else if(s=="--N")N=std::stoi(argv[++i]);else if(s=="--T")T=std::stod(argv[++i]);}
    int steps=std::lround(T/h),stride=16,nt=steps/stride+1;
    struct RefResult {std::vector<std::array<double,15>>a;Diagnostics dg;};
    std::vector<RefResult>ans(R); auto start=std::chrono::steady_clock::now();
    #pragma omp parallel for schedule(dynamic)
    for(int rep=0;rep<R;rep++){
        auto&r=ans[rep];r.a.resize(nt);r.a[0].fill(0.);
        std::mt19937_64 rng(40260913ULL+1000003ULL*N+7919ULL*(rep+1));
        std::normal_distribution<double>normal(0.,1.);
        std::array<std::vector<double>,8>Yc,Xc,Yf,Xf;
        for(int l=0;l<8;l++){Yc[l].resize(N);Xc[l].resize(N);Yf[l].resize(N);Xf[l].resize(N);for(int i=0;i<N;i++){double g=normal(rng);Yc[l][i]=Xc[l][i]=Yf[l][i]=Xf[l][i]=g;}}
        std::vector<double>zc,xc,zf,xf,noise1(N),noise2(N);int saved=1;
        for(int step=1;step<=steps;step++){
            for(int l=0;l<8;l++){
                for(int i=0;i<N;i++){noise1[i]=2*std::sqrt(h/2)*normal(rng);noise2[i]=2*std::sqrt(h/2)*normal(rng);}
                drift(zc,Yc[l],N,h,true,r.dg);drift(xc,Xc[l],N,h,false,r.dg);
                drift(zf,Yf[l],N,h/2,true,r.dg);drift(xf,Xf[l],N,h/2,false,r.dg);
                for(int i=0;i<N;i++){Yc[l][i]=zc[i]+noise1[i]+noise2[i];Xc[l][i]=xc[i]+noise1[i]+noise2[i];Yf[l][i]=zf[i]+noise1[i];Xf[l][i]=xf[i]+noise1[i];}
                drift(zf,Yf[l],N,h/2,true,r.dg);drift(xf,Xf[l],N,h/2,false,r.dg);
                for(int i=0;i<N;i++){Yf[l][i]=zf[i]+noise2[i];Xf[l][i]=xf[i]+noise2[i];}
            }
            if(step%stride==0){double sc=0,sf=0,sd=0;int p=0;for(int l=0;l<8;l++){for(int i=0;i<N;i++){double ec=Yc[l][i]-Xc[l][i],ef=Yf[l][i]-Xf[l][i];sc+=ec*ec/N;sf+=ef*ef/N;sd+=(ec-ef)*(ec-ef)/N;}if(l+1==2||l+1==3||l+1==4||l+1==5||l+1==8){r.a[saved][p]=sc;r.a[saved][5+p]=sf;r.a[saved][10+p]=sd;p++;}}saved++;}
        }
    }
    std::ofstream f(out+"/raw_refinement.csv");f<<"N,rep,t,c_d2,c_d3,c_d4,c_d5,c_d8,f_d2,f_d3,f_d4,f_d5,f_d8,diff_d2,diff_d3,diff_d4,diff_d5,diff_d8\n"<<std::setprecision(17);
    for(int rep=0;rep<R;rep++)for(int k=0;k<nt;k++){f<<N<<","<<rep+1<<","<<k*stride*h;for(double v:ans[rep].a[k])f<<","<<v;f<<"\n";}
    std::cerr<<"REFINE DONE "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<" seconds\n";
}
